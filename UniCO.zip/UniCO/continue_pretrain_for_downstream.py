#!/usr/bin/env python
# coding=utf-8
"""
continue_pretrain_for_downstream.py
===================================
面向下游 zero-shot 达标的下游精炼续训脚本(新增脚本, 不修改 pretraining_unico_lora.py)。

复用项目原有训练底座(pretraining_unico_lora 的模型构建/LoRA注入/冻结策略/三阶段调度
/NaN守卫全部经 import 复用), 在"分子预训练 + 通用图阶段二预训练"之后的 checkpoint 上
继续训练一小段, 产出【单一一套完整 checkpoint 目录】, 可直接被
downstream_test_lora.py 以 --checkpoint <目录> 加载评测, 无需修改测试脚本。

【参数更新策略】(与项目原有范式一致)
 - 原有 UniCO 主干(T5 encoder/decoder/embedding/lm_head): 冻结;
 - 新增主干模块(graph_node_feature/edge_feature_embedding/各 norm/alpha/beta/text_bias):
   可训练, 接续训练用保守学习率;
 - LoRA 参数(lora_A/lora_B): 可训练, 接续训练用保守学习率;
 - 使用原三阶段分组调度(校准段/主体段/收尾段), 峰值学习率低于阶段一/阶段二。

【输出格式】与 pretraining_unico_lora.py 完全一致:
 <output_dir>/pytorch_model.bin + config.json + tokenizer 文件 + trainer_state.json 等,
 以及 <output_dir>/checkpoint-*/ 中间存档。

【用法】(与 pretraining_unico_lora.py 相同, 多了 --load_full_weights_from 必填)
  单卡:
    python continue_pretrain_for_downstream.py \
      --model_name_or_path ckpts/gimlet --tokenizer_name t5-small \
      --transformer_backbone unico --do_train --do_eval \
      --train_file processed_mixed_pretrain_dataset \
      --validation_file processed_mixed_pretrain_dataset \
      --transform_in_collator --line_by_line \
      --load_full_weights_from ckpts/gimlet_lora_new_829_uni/checkpoint-12000 \
      --per_device_train_batch_size 16 --gradient_accumulation_steps 2 \
      --per_device_eval_batch_size 32 --max_steps 4000 \
      --save_steps 2000 --eval_steps 2000 --logging_steps 200 \
      --loss_reduction_method sentence \
      --cov_max_order 5 --projection_resample_steps 50 --alpha_init 0.03 \
      --beta_init 0.03 --operator_scale 0.5 --cov_clip_value 8 --operator_dropout 0.05 \
      --lora_rank 16 --lora_alpha 32 --lora_dropout 0.05 \
      --lora_warm_lr 1e-5 --lora_lr 3e-5 --lora_stabilization_lr 2e-5 --lora_final_lr 1e-5 \
      --new_module_lr 1e-4 --new_module_main_lr 2e-5 --new_module_stabilization_lr 1.5e-5 \
      --new_module_final_lr 1e-5 \
      --calibration_ratio 0.05 --stabilization_ratio 0.10 --seed 42 \
      --output_dir ckpts/gimlet_lora_829_downstream --overwrite_output_dir
  3卡分布式: 加前缀 CUDA_VISIBLE_DEVICES=0,1,2 python -m torch.distributed.launch \
      --nproc_per_node=3 (并相应调整 batch/累积)
"""

import logging
import os
import sys

import torch

# 复用项目原有训练底座(全部组件从 pretraining_unico_lora 导入)
from pretraining_unico_lora import (
    DataTrainingArguments,
    HfArgumentParser,
    LoRATrainingArguments,
    ModelArguments,
    TrainingArguments,
    ThreeStageLoRATrainer,
    freeze_backbone_train_lora_and_new_modules,
    graph_text_collator_dict,
    graph_text_tokenizer_dict,
    inject_lora,
    load_raw_datasets,
    logger,
    set_seed,
)
from basic_pipeline import load_graph_args
from model import get_model

from transformers import AutoTokenizer


def main():
    parser = HfArgumentParser((ModelArguments, DataTrainingArguments,
                               TrainingArguments, LoRATrainingArguments))
    model_args, data_args, training_args, lora_args, left = \
        parser.parse_args_into_dataclasses(return_remaining_strings=True)
    model_args, graph_args = load_graph_args(model_args, left)

    logging.basicConfig(format="%(asctime)s - %(levelname)s - %(name)s - %(message)s",
                        handlers=[logging.StreamHandler(sys.stdout)])
    logger.setLevel(training_args.get_process_log_level())
    set_seed(training_args.seed)

    # 必须指定接续起点(已训练完成的干净 checkpoint)
    assert lora_args.load_full_weights_from is not None, \
        "接续训练必须通过 --load_full_weights_from 指定起点 checkpoint"
    assert os.path.isfile(os.path.join(lora_args.load_full_weights_from, "pytorch_model.bin")), \
        "起点 checkpoint 目录缺少 pytorch_model.bin"

    # 数据: 阶段二混合预训练集(节点预测+边预测)
    raw_datasets = load_raw_datasets(data_args, training_args, model_args)
    tokenizer = AutoTokenizer.from_pretrained(model_args.tokenizer_name)

    # 模型: 基础 UniCO + LoRA 注入 + 冻结策略(与原脚本一致)
    model = get_model(model_args, graph_args, tokenizer)
    inject_lora(model, lora_args.lora_targets, lora_args.lora_rank,
                lora_args.lora_alpha, lora_args.lora_dropout)
    freeze_backbone_train_lora_and_new_modules(model)

    # 完整恢复起点权重(含 NaN 守卫, 逻辑与原脚本一致)
    state_dict = torch.load(os.path.join(lora_args.load_full_weights_from, "pytorch_model.bin"),
                            map_location="cpu")
    non_finite = [k for k, v in state_dict.items()
                  if v.is_floating_point() and not torch.isfinite(v).all()]
    if non_finite:
        raise ValueError("起点 checkpoint 含 %d 个 NaN/Inf 张量, 不可用: %s"
                         % (len(non_finite), non_finite[:5]))
    missing_keys, unexpected_keys = model.load_state_dict(state_dict, strict=False)
    logger.info("接续起点: %s | missing=%d unexpected=%d"
                % (lora_args.load_full_weights_from, len(missing_keys), len(unexpected_keys)))

    # tokenize(与原脚本相同)
    column_names = raw_datasets["train"].column_names
    text_column_name = "text" if "text" in column_names else column_names[0]
    max_seq_length = data_args.max_seq_length or min(tokenizer.model_max_length, 1024)
    padding = "max_length" if data_args.pad_to_max_length else False
    tokenize_function = lambda x: graph_text_tokenizer_dict[model_args.transformer_backbone](
        examples=x, tokenizer=tokenizer, text_column_name=text_column_name, padding=padding,
        max_seq_length=max_seq_length, rich_features=data_args.rich_features,
        transform_in_collator=(data_args.transform_in_collator or data_args.wrap_dataset))
    with training_args.main_process_first(desc="dataset map tokenization"):
        tokenized_datasets = raw_datasets.map(
            tokenize_function, batched=False, num_proc=data_args.preprocessing_num_workers,
            remove_columns=[text_column_name], load_from_cache_file=not data_args.overwrite_cache,
            desc="Running tokenizer on dataset line_by_line")

    train_dataset = tokenized_datasets["train"] if training_args.do_train else None
    eval_dataset = tokenized_datasets["validation"] if training_args.do_eval else None

    pad_to_multiple_of_8 = data_args.line_by_line and training_args.fp16 \
        and not data_args.pad_to_max_length
    data_collator = graph_text_collator_dict[model_args.transformer_backbone](
        tokenizer=tokenizer, mlm_probability=data_args.mlm_probability,
        pad_to_multiple_of=8 if pad_to_multiple_of_8 else None,
        transform_in_collator=data_args.transform_in_collator,
        rich_features=data_args.rich_features)

    training_args.remove_unused_columns = False
    trainer = ThreeStageLoRATrainer(
        model=model, args=training_args, train_dataset=train_dataset,
        eval_dataset=eval_dataset, tokenizer=tokenizer, data_collator=data_collator,
        lora_train_args=lora_args)

    if training_args.do_train:
        checkpoint = training_args.resume_from_checkpoint
        if checkpoint is None and os.path.isdir(training_args.output_dir) \
                and not training_args.overwrite_output_dir:
            from transformers.trainer_utils import get_last_checkpoint
            checkpoint = get_last_checkpoint(training_args.output_dir)
        train_result = trainer.train(resume_from_checkpoint=checkpoint)
        # 完整 checkpoint 落盘(pytorch_model.bin + config + tokenizer), 供
        # downstream_test_lora.py --checkpoint <output_dir> 直接加载
        trainer.save_model()
        trainer.log_metrics("train", train_result.metrics)
        trainer.save_metrics("train", train_result.metrics)
        trainer.save_state()
        logger.info("完成! 产出权重目录: %s" % training_args.output_dir)
        logger.info("评测: downstream_test_lora.py --checkpoint %s ..." % training_args.output_dir)


if __name__ == "__main__":
    main()
