#!/usr/bin/env python
# coding=utf-8
"""
pretrain_edge_prediction_generation.py
======================================
边预测(链接预测)预训练数据集构建脚本, 兼容 arxiv_2023 / pubmed / reddit 三个数据集。

输出格式与 haitengzhao/molecule_property_instruction 完全对齐
(列: graph / text / label / dataset_name / task_index / molecule_index / split /
 graph_domain), 可直接喂给 pretraining_unico_lora.py(必须带 --transform_in_collator)。

【图构造逻辑】(每个待预测节点对 (u, v))
 1. 复用 pretrain_data_generation.py 的子图提取函数 sample_one_ego_subgraph
    (本脚本不修改原脚本, 通过 import 复用, 保证提取逻辑完全一致),
    分别提取 u 的 3 跳子图 G_u、v 的 3 跳子图 G_v;
 2. 拼接得到联合拓扑图: 邻接矩阵 A_pair = diag(A_u, A_v) —— G_u 与 G_v 之间
    没有任何跨子图边(无论 u、v 是否相连), 联合图天然不连通;
    节点特征 X_pair = [X_u; X_v](纵向拼接, 各自已零填充至 512 维);
 3. G_v 的边索引整体偏移 |G_u| 后与 G_u 拼接, 构成一个图的 dict:
       {edge_index: [2, E_u+E_v], edge_feat: [[-1.0]] 占位, node_feat: [n_u+n_v, 512], num_nodes}

【正负样本采样】
 - 使用 5 组不同随机种子(可配置), 每组种子独立采样一次;
 - arxiv_2023 / pubmed: 每次采样原图 10% 真实边作为正样本, 等量采样不存在的
   节点对作为负样本;
 - reddit: 边规模巨大, 每次采样原图 5% 真实边 + 等量负样本;
 - 全图穷举节点对不可行: 负样本采用"随机抽对 + 邻接集合校验"方式, 严格按比例
   采样, 避免数据集爆炸;
 - 约束: 采样的节点对中 G_u、G_v 的节点数都必须 > 1(负样本抽到孤立端点时重抽);
 - 真实边 = 原图 edge_index 中的有向边对(去重、排除自环);
   负样本 = 两个方向上均不存在的节点对(无向非相邻)。

【指令与标签】
 - 指令: 拼接节点 u、v 各自的 summary, 末尾提问:
       "{summary_u}\n\n{summary_v}\nQuestion: Does a link exist between these two entities?"
 - 标签: 存在边 → "Yes"; 不存在边 → "No"(大写, 与分子数据集及评估逻辑一致)。

【输出目录结构】(默认 ./processed_edge_prediction_dataset)
    {ds}/       各数据集的 DatasetDict{train, validation}(save_to_disk)
    combined/   三数据集合并的 DatasetDict{train, validation}
    {ds}_train.parquet / {ds}_validation.parquet、combined_*.parquet
    dataset_stat.json

【异常防护】
 - 子图采样异常逐对 try/except; 空图/单节点子图过滤重采样;
 - 节点特征维度异常(>512 截断, <512 补零); 全零特征行置 1e-6;
 - 正样本候选不足(边数×比例 < 1)时按实际数量截断并告警;
 - summary json 与 .pt 节点数不一致直接报错。

不包含任何绘图相关代码。
"""

import argparse
import json
import os
import sys
import traceback

import numpy as np
import torch
from tqdm import tqdm

# 复用 pretrain_data_generation.py 的加载与子图提取函数(不修改原脚本)
from pretrain_data_generation import (
    DATASET_CFG,
    build_adjacency,
    load_pt_file,
    sample_one_ego_subgraph,
    _field,
)

# ===================== 全局配置 =====================
DATA_DIR = "./data_academic"
OUTPUT_DIR = "./processed_edge_prediction_dataset"

# 各数据集正样本采样比例(真实边采样比例); 负样本等量
POS_RATIO_CFG = {
    "arxiv_2023": 0.10,   # 每次采样原图 10% 真实边
    "pubmed": 0.10,
    "reddit": 0.05,       # reddit 边规模巨大, 降为 5%
}

# POS_RATIO_CFG = {
#     "arxiv_2023": 0.08,   # 每次采样原图 10% 真实边
#     "pubmed": 0.08,
#     "reddit": 0.04,       # reddit 边规模巨大, 降为 5%
# }

SEEDS = [42, 1234, 2023, 3407, 65537]   # 5 组不同随机种子
# SEEDS = [42, 1234, 2023]   # 3 组不同随机种子
HOP = 3                                 # 子图跳数(3跳子图)
VAL_RATIO = 0.05                        # 验证集样本占比(样本对级别)

# 子图提取参数(与 pretrain_data_generation.py 的 SAMPLER_CFG 对应值一致;
# min_nodes 传 visit_cap 使 BFS 始终扩展到 max_hop=3 层, 即完整 3 跳子图)
SAMPLER_ARGS = {
    "min_nodes": 5000,     # 等效于"扩满 3 跳"(见 sample_3hop_subgraph 注释)
    "max_nodes": 25,       # 按 BFS 距离裁剪上限
    "max_hop": HOP,
    "visit_cap": 5000,     # 防止高连通图(reddit)3跳爆炸
    "target_feat_dim": 512,
}

# 指令模板: 拼接 u、v 的 summary, 末尾统一提问
PROMPT_TEMPLATE = "{summary_u}\n\n{summary_v}\nQuestion: Does a link exist between these two entities?"

# 标签必须大写 Yes/No(评估时按 tokenizer('Yes')/tokenizer('No') 的 token id 取 logit)
LABEL_POS, LABEL_NEG = "Yes", "No"

# 边预测任务统一的任务标识
TASK_INDEX = "link_prediction"


# ===================== 采样工具 =====================
def sample_3hop_subgraph(center_node, adj_undir, adj_dir, node_feat, sampler_args):
    """提取 center_node 的完整 3 跳子图(复用 pretrain_data_generation 的函数)。

    sample_one_ego_subgraph 的 BFS 在 达到 min_nodes / max_hop / visit_cap 时停止;
    将 min_nodes 置为 visit_cap 后, 停止条件只剩 max_hop 与 visit_cap,
    即"始终扩满 3 跳(除非触达访问上限)", 再按 BFS 距离裁剪到 max_nodes。
    返回 smiles2graph 风格 dict: {edge_index, edge_feat, node_feat, num_nodes};
    失败(异常/空子图)返回 None。
    """
    return sample_one_ego_subgraph(
        center_node=center_node,
        adj_undir=adj_undir,
        adj_dir=adj_dir,
        node_feat=node_feat,
        min_nodes=sampler_args["min_nodes"],
        max_nodes=sampler_args["max_nodes"],
        max_hop=sampler_args["max_hop"],
        visit_cap=sampler_args["visit_cap"],
    )


def build_joint_graph(graph_u, graph_v):
    """拼接 G_u、G_v 得到联合拓扑图。

    邻接矩阵 A_pair = diag(A_u, A_v): 仅保留两子图内部边, 子图间无边,
    联合图天然不连通; 节点特征 X_pair = [X_u; X_v]。
    """
    n_u = graph_u["num_nodes"]
    # G_v 的边索引整体偏移 n_u
    src_v = [u + n_u for u in graph_v["edge_index"][0]]
    dst_v = [v + n_u for v in graph_v["edge_index"][1]]
    edge_index = [graph_u["edge_index"][0] + src_v,
                  graph_u["edge_index"][1] + dst_v]
    edge_count = len(edge_index[0])

    node_feat_u = np.asarray(graph_u["node_feat"], dtype=np.float32)
    node_feat_v = np.asarray(graph_v["node_feat"], dtype=np.float32)
    node_feat = np.concatenate([node_feat_u, node_feat_v], axis=0)

    return {
        "edge_index": edge_index,                                   # [2, E_u+E_v]
        "edge_feat": np.full((edge_count, 1), -1.0, dtype=np.float32),  # 无边特征占位
        "node_feat": np.ascontiguousarray(node_feat, dtype=np.float32), # [n_u+n_v, 512]
        "num_nodes": int(n_u + graph_v["num_nodes"]),
    }


def sample_positive_pairs(edge_pairs, n_pos, rng):
    """从真实边集合(去重、无自环的有向边对)中无放回采样 n_pos 个正样本节点对。"""
    rng.shuffle(edge_pairs)
    return [tuple(pair) for pair in edge_pairs[:n_pos]]


def sample_negative_pairs(num_nodes, edge_set, n_neg, rng, max_try=100):
    """随机采样不存在的节点对(两个方向均无边的无向非相邻对)作为负样本。

    全图穷举节点对不可行, 采用"随机抽对 + 邻接集合校验", 严格按数量采样。
    edge_set: 有向边对集合(含两个方向), 用于 O(1) 校验连边。
    """
    neg_pairs = []
    while len(neg_pairs) < n_neg:
        u = int(rng.integers(0, num_nodes))
        v = int(rng.integers(0, num_nodes))
        if u == v:
            continue
        if (u, v) in edge_set or (v, u) in edge_set:
            continue
        neg_pairs.append((u, v))
    return neg_pairs


def build_samples_for_pairs(pairs, is_positive, adj_undir, adj_dir, node_feat,
                            id2summary, ds_name, sampler_args, rng, edge_set=None,
                            max_resample=20):
    """对节点对列表构造指令样本(含 G_u/G_v 有效性校验与负样本重采样)。"""
    samples = []
    for u, v in tqdm(pairs, desc="构造样本"):
        # 有效性约束: G_u 与 G_v 的节点数都必须 > 1(负样本抽到孤立端点时重抽)
        graph_u = graph_v = None
        for _ in range(max_resample):
            if graph_u is None:
                graph_u = sample_3hop_subgraph(u, adj_undir, adj_dir, node_feat, sampler_args)
            if graph_v is None:
                graph_v = sample_3hop_subgraph(v, adj_undir, adj_dir, node_feat, sampler_args)
            if graph_u is not None and graph_v is not None and \
                    graph_u["num_nodes"] > 1 and graph_v["num_nodes"] > 1:
                break
            # 无效: 重新采一个负样本节点对; 正样本理论必有效(u,v 有边, 互在1跳内)
            if is_positive:
                print("[warn] 正样本 (%d,%d) 子图无效, 跳过" % (u, v))
                graph_u = graph_v = None
                break
            # 负样本重采样: 必须仍然是无向非相邻节点对(校验 edge_set, 避免标签噪声)
            u = int(rng.integers(0, node_feat.size(0)))
            v = int(rng.integers(0, node_feat.size(0)))
            while (u == v) or ((u, v) in edge_set) or ((v, u) in edge_set):
                u = int(rng.integers(0, node_feat.size(0)))
                v = int(rng.integers(0, node_feat.size(0)))
            graph_u = graph_v = None
        if graph_u is None or graph_v is None:
            continue

        try:
            joint = build_joint_graph(graph_u, graph_v)
        except Exception:
            print("[warn] 节点对 (%d,%d) 联合图构造失败: %s" % (u, v, traceback.format_exc(limit=1)))
            continue

        prompt = PROMPT_TEMPLATE.format(
            summary_u=id2summary.get(u, ""), summary_v=id2summary.get(v, ""))
        samples.append({
            "graph": joint,
            "text": [prompt],  # sequence[string], 与分子数据集 text 列一致
            "label": LABEL_POS if is_positive else LABEL_NEG,
            "dataset_name": ds_name,
            "task_index": TASK_INDEX,
            "molecule_index": "%d_%d" % (u, v),  # 该列存源节点对标识
            "split": "train",  # 实际 split 在下方按比例重写
            "graph_domain": "general",  # 走通用图分支(连续浮点特征)
        })
    return samples


# ===================== 单数据集单种子处理 =====================
def preprocess_dataset_seed(ds_name, seed, args):
    cfg = DATASET_CFG[ds_name]
    pos_ratio = POS_RATIO_CFG[ds_name]
    sampler_args = dict(SAMPLER_ARGS)
    sampler_args["max_nodes"] = args.max_nodes
    sampler_args["visit_cap"] = args.visit_cap
    sampler_args["min_nodes"] = args.visit_cap  # 扩满 HOP 跳(见 sample_3hop_subgraph)

    pt_path = os.path.join(args.data_dir, cfg["pt_file"])
    json_path = os.path.join(args.data_dir, cfg["summary_json"])

    print("\n==== %s [seed=%d]: 加载数据 ====" % (ds_name, seed))
    data = load_pt_file(pt_path)
    x = torch.as_tensor(_field(data, "x"))
    edge_index = torch.as_tensor(_field(data, "edge_index"))
    if x is None or edge_index is None:
        raise ValueError("%s: .pt 缺少 x/edge_index 字段" % ds_name)
    num_nodes = x.size(0)
    if edge_index.numel() > 0 and edge_index.size(0) != 2:
        raise ValueError("%s: edge_index 形状异常 %s" % (ds_name, tuple(edge_index.shape)))

    with open(json_path, "r", encoding="utf-8") as f:
        sum_list = json.load(f)
    id2summary = {item["id"]: item.get("summary", "") for item in sum_list}
    if len(id2summary) != num_nodes:
        raise ValueError("%s: summary json 节点数(%d)与 .pt 节点数(%d)不匹配!"
                         % (ds_name, len(id2summary), num_nodes))

    # ---- 边集合: 去重、排除自环的有向边对 ----
    edge_pairs = []
    edge_set = set()
    for u, v in zip(edge_index[0].tolist(), edge_index[1].tolist()):
        if u == v:
            continue  # 排除自环
        edge_set.add((u, v))
    edge_pairs = list(edge_set)
    n_pos = int(len(edge_pairs) * pos_ratio)
    if n_pos < 1:
        print("[warn] %s 真实边 %d × %.2f 不足1个正样本, 跳过" % (ds_name, len(edge_pairs), pos_ratio))
        return [], []
    print("  [统计] 真实边(去重无自环) %d, 正样本 %d, 负样本 %d" % (len(edge_pairs), n_pos, n_pos))

    rng = np.random.default_rng(seed)

    # ---- 正负采样 ----
    pos_pairs = sample_positive_pairs(edge_pairs, n_pos, rng)
    neg_pairs = sample_negative_pairs(num_nodes, edge_set, n_pos, rng)

    # ---- 构造样本 ----
    adj_undir, adj_dir = build_adjacency(num_nodes, edge_index)
    pos_samples = build_samples_for_pairs(pos_pairs, True, adj_undir, adj_dir, x,
                                          id2summary, ds_name, sampler_args, rng, edge_set)
    neg_samples = build_samples_for_pairs(neg_pairs, False, adj_undir, adj_dir, x,
                                          id2summary, ds_name, sampler_args, rng, edge_set)

    # ---- 样本对级别划分 train/validation ----
    rng.shuffle(pos_samples)
    rng.shuffle(neg_samples)
    n_val_pos = max(1, int(len(pos_samples) * args.val_ratio)) if pos_samples else 0
    n_val_neg = max(1, int(len(neg_samples) * args.val_ratio)) if neg_samples else 0
    train_samples = pos_samples[n_val_pos:] + neg_samples[n_val_neg:]
    val_samples = pos_samples[:n_val_pos] + neg_samples[:n_val_neg]
    for s in train_samples:
        s["split"] = "train"
    for s in val_samples:
        s["split"] = "validation"
    print("  [统计] seed=%d: train %d, val %d" % (seed, len(train_samples), len(val_samples)))
    return train_samples, val_samples


# ===================== 保存与主流程 =====================
def save_dataset(ds_dir, train_samples, val_samples):
    """save_to_disk 保存 DatasetDict{train, validation}。"""
    from datasets import Dataset, DatasetDict
    train_ds = Dataset.from_list(train_samples) if train_samples else Dataset.from_dict({})
    val_ds = Dataset.from_list(val_samples) if val_samples else Dataset.from_dict({})
    DatasetDict({"train": train_ds, "validation": val_ds}).save_to_disk(ds_dir)
    return train_ds, val_ds


def main():
    parser = argparse.ArgumentParser(description="边预测预训练数据集构建(arxiv_2023/pubmed/reddit)")
    parser.add_argument("--data_dir", type=str, default=DATA_DIR)
    parser.add_argument("--output_dir", type=str, default=OUTPUT_DIR)
    parser.add_argument("--datasets", nargs="+", default=["arxiv_2023", "pubmed", "reddit"])
    parser.add_argument("--seeds", type=str, default=",".join(map(str, SEEDS)),
                        help="逗号分隔的随机种子列表(默认5组)")
    parser.add_argument("--hop", type=int, default=HOP)
    parser.add_argument("--max_nodes", type=int, default=SAMPLER_ARGS["max_nodes"])
    parser.add_argument("--visit_cap", type=int, default=SAMPLER_ARGS["visit_cap"])
    parser.add_argument("--val_ratio", type=float, default=VAL_RATIO)
    parser.add_argument("--skip_parquet", action="store_true", help="不输出单文件 parquet")
    args = parser.parse_args()

    seeds = [int(s) for s in args.seeds.split(",") if s.strip()]
    SAMPLER_ARGS["max_hop"] = args.hop
    os.makedirs(args.output_dir, exist_ok=True)
    stats = {}

    # ---- 逐数据集 × 逐种子处理并落盘(控制峰值内存, 与 pretrain_data_generation 同策略) ----
    sub_dirs = []
    for ds_name in args.datasets:
        if ds_name not in DATASET_CFG:
            print("[warn] 未知数据集 %s, 跳过" % ds_name)
            continue
        ds_train, ds_val = [], []
        for seed in seeds:
            try:
                train_samples, val_samples = preprocess_dataset_seed(ds_name, seed, args)
            except Exception:
                print("[error] %s seed=%d 处理失败, 跳过: %s"
                      % (ds_name, seed, traceback.format_exc(limit=2)))
                continue
            ds_train.extend(train_samples)
            ds_val.extend(val_samples)
            del train_samples, val_samples

        if not ds_train and not ds_val:
            print("[warn] %s 无任何样本, 跳过" % ds_name)
            continue
        stats[ds_name] = {"train": len(ds_train), "validation": len(ds_val)}
        sub_dir = os.path.join(args.output_dir, ds_name)
        save_dataset(sub_dir, ds_train, ds_val)
        if not args.skip_parquet:
            from datasets import Dataset
            Dataset.from_list(ds_train).to_parquet(
                os.path.join(args.output_dir, "%s_train.parquet" % ds_name))
            Dataset.from_list(ds_val).to_parquet(
                os.path.join(args.output_dir, "%s_validation.parquet" % ds_name))
        sub_dirs.append(sub_dir)
        del ds_train, ds_val

    # ---- 从已落盘分区 mmap 拼接 combined ----
    if sub_dirs:
        from datasets import concatenate_datasets, load_from_disk, DatasetDict
        combined_dir = os.path.join(args.output_dir, "combined")
        parts_train = [load_from_disk(d)["train"] for d in sub_dirs]
        parts_val = [load_from_disk(d)["validation"] for d in sub_dirs]
        combined_train = concatenate_datasets(parts_train)
        combined_val = concatenate_datasets(parts_val)
        DatasetDict({"train": combined_train, "validation": combined_val}).save_to_disk(combined_dir)
        if not args.skip_parquet:
            combined_train.to_parquet(os.path.join(args.output_dir, "combined_train.parquet"))
            combined_val.to_parquet(os.path.join(args.output_dir, "combined_validation.parquet"))
        stats["combined"] = {"train": len(combined_train), "validation": len(combined_val)}
        print("\n[done] 边预测数据集: train %d, validation %d" % (len(combined_train), len(combined_val)))
    else:
        print("\n[warn] 未生成任何样本, 请检查 --datasets 与数据文件")

    with open(os.path.join(args.output_dir, "dataset_stat.json"), "w", encoding="utf-8") as f:
        json.dump(stats, f, indent=2, ensure_ascii=False)
    print("==== 全部完成, 输出目录: %s ====" % os.path.abspath(args.output_dir))
    for k, v in stats.items():
        print("  %-12s %s" % (k, v))


if __name__ == "__main__":
    main()
