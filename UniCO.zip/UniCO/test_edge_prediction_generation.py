#!/usr/bin/env python
# coding=utf-8
"""
test_edge_prediction_generation.py
==================================
边预测下游测试数据集构建脚本, 兼容 cora / wikics / citeseer 三个学术图数据集
(./data_academic/target_data 下的 .pt 文件; instagram 不需要边预测测试集)。

联合子图采样、文本指令模板、标签生成逻辑完全复用
pretrain_edge_prediction_generation.py 的边预测构造逻辑(通过 import 复用,
不修改原脚本): 每个待预测节点对 (u,v) 提取 u、v 各自的 3 跳子图, 拼接得到
联合拓扑图(邻接 diag(A_u,A_v), 子图间无边, 天然不连通)。

输出目录结构、样本字段格式与 ./property_data 下 bace/tox21/muv 完全对齐,
可直接被 downstream_test_lora.py 读取和评测:

    property_data/{name}_edge/
        raw/{name}_edge.csv                节点对文本(每行一条, 结构对齐用)
        processed/rich_data_ogb_encoding.pt PyG InMemoryDataset 格式(data, slices)
        processed/smiles.csv                节点对文本(供 scaffold 类 split 使用)
        {NAME}_EDGE_README                  数据集说明

【采样规则】(参考 pretrain_edge_prediction_generation.py, 下游测试集默认单种子)
 - 正样本: 采样原图真实边(去重、排除自环的有向边对), cora/citeseer 10% / wikics 5%;
 - 负样本: 等量采样无向非相邻节点对(随机抽对 + 邻接集合校验, 不穷举全图);
 - 约束: G_u、G_v 节点数都必须 > 1(孤立端点重采样);
 - 标签: 存在边 → y=1.0("Yes"), 不存在边 → y=0.0("No"), 单 task;
 - 指令: 评测时由 transform 将节点对文本前置注入
   "<节点对文本>\nQuestion: Does a link exist between these two entities?"

【使用】
    python test_edge_prediction_generation.py                       # cora + wikics + citeseer
    python test_edge_prediction_generation.py --datasets cora --pos_ratio 0.1
    # 评测:
    python downstream_test_lora.py --dataset cora_edge --model_name_or_path <ckpt> \
        --tokenizer_name t5-small --transformer_backbone gimlet \
        --prompt_file prompt_downstream_academic.json --split random \
        --transform_in_collator --zero_shot --batch_size 8 ...

不包含任何绘图相关代码。
"""

import argparse
import json
import os
import traceback

import numpy as np
import torch
from tqdm import tqdm

# 复用 pretrain_data_generation.py 的加载/邻接构建
from pretrain_data_generation import build_adjacency, load_pt_file, _field
# 复用 pretrain_edge_prediction_generation.py 的边预测构造逻辑(不修改原脚本)
import pretrain_edge_prediction_generation as epg
from pretrain_edge_prediction_generation import (
    build_samples_for_pairs,
    sample_negative_pairs,
    sample_positive_pairs,
    SAMPLER_ARGS,
)

# 【下游数据差异】下游数据集中样本级文本只存节点对摘要, 问题句由静态 prompt
# (prompts/prompt_downstream_academic.json) 提供, 避免问题句重复;
# 预训练数据集则使用完整模板(含问题句), 两者通过模块级模板切换, 不修改原脚本。
epg.PROMPT_TEMPLATE = "{summary_u}\n\n{summary_v}"

# ===================== 全局配置 =====================
DATA_DIR = "./data_academic/target_data"
OUTPUT_DIR = "./property_data"   # 与分子下游测试数据(bace/tox21/muv)同目录

# 边预测测试集配置(instagram 不生成; 下游测试默认单种子, 可配置)
DATASET_CFG = {
    "cora":     {"pt_file": "cora.pt",     "pos_ratio": 0.10},  # 10%
    "wikics":   {"pt_file": "wikics.pt",   "pos_ratio": 0.05},  # 边规模大, 5%
    "citeseer": {"pt_file": "citeseer.pt", "pos_ratio": 0.10},  # 10%
}
DEFAULT_SEEDS = [42]


# ===================== 单数据集处理 =====================
def preprocess_single_dataset(ds_name, seed, args):
    cfg = DATASET_CFG[ds_name]
    pt_path = os.path.join(args.data_dir, cfg["pt_file"])
    sampler_args = dict(SAMPLER_ARGS)
    sampler_args["max_nodes"] = args.max_nodes
    sampler_args["visit_cap"] = args.visit_cap
    sampler_args["min_nodes"] = args.visit_cap  # 扩满 3 跳(见 sample_3hop_subgraph)

    print("\n==== %s [seed=%d]: 加载数据 ====" % (ds_name, seed))
    data = load_pt_file(pt_path)
    x = torch.as_tensor(_field(data, "x"))
    edge_index = torch.as_tensor(_field(data, "edge_index"))
    if x is None or edge_index is None:
        raise ValueError("%s: .pt 缺少 x/edge_index 字段" % ds_name)
    num_nodes = x.size(0)
    if edge_index.numel() > 0 and edge_index.size(0) != 2:
        raise ValueError("%s: edge_index 形状异常 %s" % (ds_name, tuple(edge_index.shape)))

    raw_texts = _field(data, "raw_texts", None)
    if raw_texts is None or len(raw_texts) != num_nodes:
        print("  [warn] %s 缺少 raw_texts, 使用 'Node {id}' 占位" % ds_name)
        raw_texts = ["Node %d" % i for i in range(num_nodes)]
    id2summary = {i: str(raw_texts[i]) for i in range(num_nodes)}

    # ---- 边集合(去重、排除自环的有向边对)与正负采样 ----
    edge_pairs = []
    edge_set = set()
    for u, v in zip(edge_index[0].tolist(), edge_index[1].tolist()):
        if u == v:
            continue
        edge_set.add((u, v))
    edge_pairs = list(edge_set)
    n_pos = int(len(edge_pairs) * args.pos_ratio)
    if n_pos < 1:
        raise ValueError("%s: 真实边 %d × %.2f 不足1个正样本" % (ds_name, len(edge_pairs), args.pos_ratio))
    print("  [统计] 真实边(去重无自环) %d, 正样本 %d, 负样本 %d" % (len(edge_pairs), n_pos, n_pos))

    rng = np.random.default_rng(seed)
    pos_pairs = sample_positive_pairs(edge_pairs, n_pos, rng)
    neg_pairs = sample_negative_pairs(num_nodes, edge_set, n_pos, rng)

    # ---- 构造样本(与预训练边预测构造逻辑一致) ----
    adj_undir, adj_dir = build_adjacency(num_nodes, edge_index)
    pos_samples = build_samples_for_pairs(pos_pairs, True, adj_undir, adj_dir, x,
                                          id2summary, ds_name, sampler_args, rng, edge_set)
    neg_samples = build_samples_for_pairs(neg_pairs, False, adj_undir, adj_dir, x,
                                          id2summary, ds_name, sampler_args, rng, edge_set)
    print("  [统计] 有效样本: 正 %d, 负 %d" % (len(pos_samples), len(neg_samples)))

    # ---- 组装 Data 列表 ----
    # 节点对文本同时存入 smiles(对齐分子数据集字段, 加载时会被删除)与 raw_texts
    # (加载器不删除, 供评测 transform 注入指令使用)
    from torch_geometric.data import Data
    data_list = []
    for s in pos_samples:
        data_list.append(Data(
            node_feat=torch.from_numpy(np.asarray(s["graph"]["node_feat"], dtype=np.float32)),
            edge_index=torch.tensor(s["graph"]["edge_index"], dtype=torch.long),
            y=torch.tensor([[1.0]], dtype=torch.float32),   # 存在边 → Yes
            smiles=s["text"][0],                            # 节点对文本
            raw_texts=s["text"][0],
            graph_domain="general",
        ))
    for s in neg_samples:
        data_list.append(Data(
            node_feat=torch.from_numpy(np.asarray(s["graph"]["node_feat"], dtype=np.float32)),
            edge_index=torch.tensor(s["graph"]["edge_index"], dtype=torch.long),
            y=torch.tensor([[0.0]], dtype=torch.float32),   # 不存在边 → No
            smiles=s["text"][0],
            raw_texts=s["text"][0],
            graph_domain="general",
        ))
    return data_list, len(pos_samples), len(neg_samples)


# ===================== 落盘(property_data 对齐格式) =====================
def save_dataset(ds_name, data_list, args):
    from torch_geometric.data import InMemoryDataset
    out_name = "%s_edge" % ds_name
    ds_dir = os.path.join(args.output_dir, out_name)
    processed_dir = os.path.join(ds_dir, "processed")
    raw_dir = os.path.join(ds_dir, "raw")
    os.makedirs(processed_dir, exist_ok=True)
    os.makedirs(raw_dir, exist_ok=True)

    data, slices = InMemoryDataset.collate(data_list)
    torch.save((data, slices), os.path.join(processed_dir, "rich_data_ogb_encoding.pt"))

    texts = [d.smiles for d in data_list]
    with open(os.path.join(processed_dir, "smiles.csv"), "w", encoding="utf-8") as f:
        f.write("\n".join(texts) + "\n")
    with open(os.path.join(raw_dir, "%s.csv" % out_name), "w", encoding="utf-8") as f:
        f.write("\n".join(texts) + "\n")

    with open(os.path.join(ds_dir, "%s_README" % out_name.upper()), "w", encoding="utf-8") as f:
        f.write("%s 边预测下游测试集(学术图, 联合子图: 邻接 diag(A_u,A_v), 子图间无边)\n" % ds_name)
        f.write("样本数: %d (正/负 = 1:1)\n" % len(data_list))
        f.write("task 数: 1 (存在边→Yes / 不存在边→No)\n")
        f.write("字段: node_feat=[n,512] float32 / edge_index / y=[1,1] / smiles=节点对文本 / graph_domain=general\n")
        f.write("评测: downstream_test_lora.py --dataset %s --prompt_file prompt_downstream_academic.json --split random --transform_in_collator\n" % out_name)

    print("  [done] %s -> %s" % (out_name, os.path.abspath(ds_dir)))
    return len(data_list)


def main():
    parser = argparse.ArgumentParser(description="边预测下游测试数据集构建(cora/wikics/citeseer)")
    parser.add_argument("--data_dir", type=str, default=DATA_DIR)
    parser.add_argument("--output_dir", type=str, default=OUTPUT_DIR)
    parser.add_argument("--datasets", nargs="+", default=["cora", "wikics", "citeseer"])
    parser.add_argument("--seeds", type=str, default=",".join(map(str, DEFAULT_SEEDS)))
    parser.add_argument("--pos_ratio", type=float, default=None,
                        help="正样本比例(默认取各数据集配置: cora/citeseer 10%%, wikics 5%%)")
    parser.add_argument("--max_nodes", type=int, default=SAMPLER_ARGS["max_nodes"])
    parser.add_argument("--visit_cap", type=int, default=SAMPLER_ARGS["visit_cap"])
    args = parser.parse_args()

    seeds = [int(s) for s in args.seeds.split(",") if s.strip()]
    stats = {}
    for ds_name in args.datasets:
        if ds_name not in DATASET_CFG:
            print("[warn] 未知数据集 %s, 跳过" % ds_name)
            continue
        # 正样本比例: 未显式指定时取各数据集配置(cora 10%, wikics 5%)
        ratio = DATASET_CFG[ds_name]["pos_ratio"] if args.pos_ratio is None else args.pos_ratio
        ds_data_list = []
        n_pos = n_neg = 0
        for seed in seeds:
            try:
                # 单数据集多种子: 按种子独立采样后合并(默认单种子)
                args.pos_ratio = ratio
                data_list, p, n = preprocess_single_dataset(ds_name, seed, args)
                ds_data_list.extend(data_list)
                n_pos += p
                n_neg += n
                del data_list
            except Exception:
                print("[error] %s seed=%d 处理失败, 跳过: %s" % (ds_name, seed, traceback.format_exc(limit=2)))
        if ds_data_list:
            total = save_dataset(ds_name, ds_data_list, args)
            stats["%s_edge" % ds_name] = {"samples": total, "positive": n_pos, "negative": n_neg}
        del ds_data_list

    with open(os.path.join(args.output_dir, "academic_edge_test_stat.json"), "w", encoding="utf-8") as f:
        json.dump(stats, f, indent=2, ensure_ascii=False)
    print("\n==== 全部完成, 输出目录: %s ====" % os.path.abspath(args.output_dir))
    for k, v in stats.items():
        print("  %-12s %s" % (k, v))


if __name__ == "__main__":
    main()
