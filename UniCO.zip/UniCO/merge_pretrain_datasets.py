#!/usr/bin/env python
# coding=utf-8
"""
merge_pretrain_datasets.py
==========================
第二阶段(通用图领域)预训练数据集合并脚本:
将"节点预测预训练集"(./processed_task_dataset/combined)与
"边预测预训练集"(./processed_edge_prediction_dataset/combined)
合并为统一的 DatasetDict{train, validation}, 供 pretraining_unico_lora.py
直接以 --train_file <输出目录> 传入(load_from_disk 路径)。

两套数据集的列结构与图 dict 类型完全一致
(graph / text / label / dataset_name / task_index / molecule_index / split /
 graph_domain, node_feat float32), 可安全拼接。

【用法】
    python merge_pretrain_datasets.py
    python merge_pretrain_datasets.py --node_dir .../processed_task_dataset/combined \
        --edge_dir .../processed_edge_prediction_dataset/combined \
        --output_dir ./processed_mixed_pretrain_dataset --seed 42
"""

import argparse
import json
import os

from datasets import DatasetDict, concatenate_datasets, load_from_disk

DEFAULT_NODE_DIR = "./processed_task_dataset/combined"
DEFAULT_EDGE_DIR = "./processed_edge_prediction_dataset/combined"
DEFAULT_OUTPUT_DIR = "./processed_mixed_pretrain_dataset"


def main():
    parser = argparse.ArgumentParser(description="合并节点预测+边预测预训练数据集")
    parser.add_argument("--node_dir", type=str, default=DEFAULT_NODE_DIR)
    parser.add_argument("--edge_dir", type=str, default=DEFAULT_EDGE_DIR)
    parser.add_argument("--output_dir", type=str, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--seed", type=int, default=42, help="合并后 shuffle 的随机种子")
    parser.add_argument("--skip_shuffle", action="store_true", help="不 shuffle(默认 shuffle)")
    parser.add_argument("--skip_parquet", action="store_true")
    args = parser.parse_args()

    print("==== 加载节点预测预训练集: %s ====" % args.node_dir)
    node = load_from_disk(args.node_dir)
    print("  train %d, validation %d" % (len(node["train"]), len(node["validation"])))
    print("==== 加载边预测预训练集: %s ====" % args.edge_dir)
    edge = load_from_disk(args.edge_dir)
    print("  train %d, validation %d" % (len(edge["train"]), len(edge["validation"])))

    # 列结构与嵌套类型完全一致, 直接拼接
    print("==== 合并 ====")
    train = concatenate_datasets([node["train"], edge["train"]])
    validation = concatenate_datasets([node["validation"], edge["validation"]])
    if not args.skip_shuffle:
        train = train.shuffle(seed=args.seed)
        validation = validation.shuffle(seed=args.seed)

    stats = {
        "node_train": len(node["train"]), "node_validation": len(node["validation"]),
        "edge_train": len(edge["train"]), "edge_validation": len(edge["validation"]),
        "mixed_train": len(train), "mixed_validation": len(validation),
    }

    os.makedirs(args.output_dir, exist_ok=True)
    DatasetDict({"train": train, "validation": validation}).save_to_disk(args.output_dir)
    if not args.skip_parquet:
        train.to_parquet(os.path.join(args.output_dir, "mixed_train.parquet"))
        validation.to_parquet(os.path.join(args.output_dir, "mixed_validation.parquet"))
    with open(os.path.join(args.output_dir, "dataset_stat.json"), "w", encoding="utf-8") as f:
        json.dump(stats, f, indent=2, ensure_ascii=False)

    print("\n==== 合并完成 -> %s ====" % os.path.abspath(args.output_dir))
    for k, v in stats.items():
        print("  %-18s %d" % (k, v))
    print("\n预训练脚本接入:")
    print("  --train_file %s" % os.path.abspath(args.output_dir))
    print("  --validation_file %s" % os.path.abspath(args.output_dir))
    print("  --transform_in_collator --line_by_line")


if __name__ == "__main__":
    main()
