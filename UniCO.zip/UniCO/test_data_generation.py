#!/usr/bin/env python
# coding=utf-8
"""
test_data_generation.py
=======================
节点(子图)分类下游测试数据集构建脚本, 兼容 cora / citeseer / wikics / instagram
四个学术/社交图数据集(./data_academic/target_data 下的 .pt 文件)。

输出目录结构、样本字段格式与 ./property_data 下的 bace/tox21/muv 完全对齐,
可直接被 downstream_test_lora.py 读取和评测(zero shot / few shot):

    property_data/{name}/
        raw/{name}.csv                      节点原始文本(每行一条, 结构对齐用)
        processed/rich_data_ogb_encoding.pt PyG InMemoryDataset 格式(data, slices)
        processed/smiles.csv                节点文本(供 scaffold 类 split 使用)
        {NAME}_README                       数据集说明

【处理逻辑】(参考 pretrain_data_generation.py)
 1. 每个节点以其为心中采样 ego 子图(同一 sample_one_ego_subgraph 函数,
    min 25 / max 50 节点 / max 5 跳), 孤立子图(<2 节点)过滤;
 2. 节点特征为 384 维连续浮点: 不截取前2维、不做分子式类别映射, 零填充至 512 维;
 3. 无边特征: 边以原样保存(edge_index), 图变换由 collator 通用图分支完成;
 4. 每一个类别视作一个独立 task: y 为 [N, T] one-hot(T=类别数),
    与 tox21(12 tasks)/muv(17 tasks)的多 task 组织方式一致;
 5. 每个样本携带节点文本(smiles 属性)与 graph_domain='general' 标记,
    评测时由 unico_add_prompt_conditional_generation_transform_single 将
    节点文本前置注入指令("<节点文本>\nQuestion: ..."), 与预训练指令格式一致。

【使用】
    python test_data_generation.py                     # 生成全部4个数据集
    python test_data_generation.py --datasets cora     # 只生成 cora
    # 评测:
    python downstream_test_lora.py --dataset cora --model_name_or_path <ckpt> \
        --tokenizer_name t5-small --transformer_backbone gimlet \
        --prompt_file prompt_downstream_academic.json --split random \
        --transform_in_collator --zero_shot --batch_size 8 ...

【异常防护】
 - .pt 文件 PyG 版本差异的兼容反序列化(缺类占位);
 - 子图采样失败逐节点捕获; 孤立节点子图过滤并统计;
 - 特征维度异常(>512 截断/<512 补零), 全零特征行置 1e-6;
 - 无 raw_texts 的节点回退 "Node {id}"; 类别数动态取自 y 唯一值。

不包含任何绘图相关代码。
"""

import argparse
import json
import os
import traceback

import numpy as np
import torch
from tqdm import tqdm

# 复用 pretrain_data_generation.py 的加载与子图提取函数(不修改原脚本)
from pretrain_data_generation import (
    build_adjacency,
    load_pt_file,
    pad_or_trim_node_feat,
    sample_one_ego_subgraph,
    SAMPLER_CFG,
    _field,
)

# ===================== 全局配置 =====================
DATA_DIR = "./data_academic/target_data"
OUTPUT_DIR = "./property_data"   # 与分子下游测试数据(bace/tox21/muv)同目录

DATASET_CFG = {
    # pt 文件中的类别数在运行时动态读取(此处注释仅作参考)
    "cora":      {"pt_file": "cora.pt",      "num_classes": 7},   # 2708 节点
    "citeseer":  {"pt_file": "citeseer.pt",  "num_classes": 6},   # 3186 节点
    "wikics":    {"pt_file": "wikics.pt",    "num_classes": 10},  # 11701 节点
    "instagram": {"pt_file": "instagram.pt", "num_classes": 2},   # 11339 节点
}


# ===================== 单数据集处理 =====================
def preprocess_single_dataset(ds_name, args):
    cfg = DATASET_CFG[ds_name]
    pt_path = os.path.join(args.data_dir, cfg["pt_file"])

    print("\n==== %s: 加载数据 ====" % ds_name)
    data = load_pt_file(pt_path)
    x = torch.as_tensor(_field(data, "x"))
    edge_index = torch.as_tensor(_field(data, "edge_index"))
    y = torch.as_tensor(_field(data, "y"))
    if x is None or edge_index is None or y is None:
        raise ValueError("%s: .pt 缺少 x/edge_index/y 字段" % ds_name)
    num_nodes = x.size(0)
    if y.dim() > 1:
        y = y.squeeze(0)
    if y.size(0) != num_nodes:
        raise ValueError("%s: y 与 x 节点数不一致(%d vs %d)" % (ds_name, y.size(0), num_nodes))
    if edge_index.numel() > 0 and edge_index.size(0) != 2:
        raise ValueError("%s: edge_index 形状异常 %s" % (ds_name, tuple(edge_index.shape)))

    # 节点文本: raw_texts 缺失时回退 "Node {id}"
    raw_texts = _field(data, "raw_texts", None)
    if raw_texts is None or len(raw_texts) != num_nodes:
        print("  [warn] %s 缺少 raw_texts, 使用 'Node {id}' 占位" % ds_name)
        raw_texts = ["Node %d" % i for i in range(num_nodes)]

    # 类别与类别名(参考 pretrain_data_generation.py: 无类别名时用 "Class i")
    classes = sorted(torch.unique(y).tolist())
    num_classes = len(classes)
    if num_classes != cfg["num_classes"]:
        print("  [warn] %s 实际类别数 %d 与配置 %d 不一致, 以实际为准" % (ds_name, num_classes, cfg["num_classes"]))
    label_name = _field(data, "label_name", None)
    if label_name is None or len(label_name) != num_classes:
        label_name = ["Class %d" % i for i in range(num_classes)]
    print("  [统计] 节点 %d, 类别 %d: %s" % (num_nodes, num_classes, label_name))

    # ---- 每节点采样 1 次子图(复用 pretrain_data_generation 的函数与默认参数) ----
    print("==== %s: 对全部 %d 节点采样子图 ====" % (ds_name, num_nodes))
    adj_undir, adj_dir = build_adjacency(num_nodes, edge_index)
    sample_list = []       # 有效样本的 (data, text)
    fail_cnt = 0
    isolated_cnt = 0
    for nid in tqdm(range(num_nodes), desc="采样子图"):
        try:
            g_item = sample_one_ego_subgraph(
                center_node=nid, adj_undir=adj_undir, adj_dir=adj_dir, node_feat=x,
                min_nodes=args.min_nodes, max_nodes=args.max_nodes, max_hop=args.max_hop,
                visit_cap=args.visit_cap)
        except Exception:
            print("[warn] 节点 %d 子图采样失败: %s" % (nid, traceback.format_exc(limit=1)))
            fail_cnt += 1
            continue
        if g_item is None or g_item["num_nodes"] < 2:  # 孤立子图过滤(与预训练一致)
            isolated_cnt += 1
            continue

        # 多 task 标签: one-hot [1, T], 与 tox21/muv 的 y 组织方式一致
        cls_idx = classes.index(int(y[nid]))
        y_onehot = np.zeros((1, num_classes), dtype=np.float32)
        y_onehot[0, cls_idx] = 1.0

        sample_list.append({
            "node_feat": np.asarray(g_item["node_feat"], dtype=np.float32),  # [n, 512]
            "edge_index": g_item["edge_index"],                             # [2, e]
            "y": y_onehot,                                                  # [1, T]
            "smiles": str(raw_texts[nid]),                                  # 节点文本
        })
    print("  [统计] 采样失败 %d, 孤立子图(<2节点) %d, 有效样本 %d" % (fail_cnt, isolated_cnt, len(sample_list)))

    if len(sample_list) == 0:
        raise ValueError("%s: 无有效样本" % ds_name)

    return sample_list, label_name


# ===================== 落盘(property_data 对齐格式) =====================
def save_dataset(ds_name, sample_list, label_name, args):
    from torch_geometric.data import Data, InMemoryDataset

    ds_dir = os.path.join(args.output_dir, ds_name)
    processed_dir = os.path.join(ds_dir, "processed")
    raw_dir = os.path.join(ds_dir, "raw")
    os.makedirs(processed_dir, exist_ok=True)
    os.makedirs(raw_dir, exist_ok=True)

    # 构造 Data 列表并 collate 为 InMemoryDataset 格式(data + slices)
    # 节点文本同时存入 smiles(对齐分子数据集字段, 加载时会被删除)与 raw_texts
    # (加载器不删除, 供评测 transform 注入指令使用)
    data_list = []
    for s in tqdm(sample_list, desc="组装 Data"):
        data_list.append(Data(
            node_feat=torch.from_numpy(np.asarray(s["node_feat"], dtype=np.float32)),
            edge_index=torch.tensor(s["edge_index"], dtype=torch.long),
            y=torch.from_numpy(np.asarray(s["y"], dtype=np.float32)),
            smiles=s["smiles"],
            raw_texts=s["smiles"],
            graph_domain="general",
        ))
    data, slices = InMemoryDataset.collate(data_list)
    torch.save((data, slices), os.path.join(processed_dir, "rich_data_ogb_encoding.pt"))

    # smiles.csv: 每样本一行节点文本(供 scaffold/random_scaffold split 使用)
    with open(os.path.join(processed_dir, "smiles.csv"), "w", encoding="utf-8") as f:
        f.write("\n".join(s["smiles"] for s in sample_list) + "\n")
    # raw/{name}.csv: 结构对齐(processed 存在时加载器不会访问)
    with open(os.path.join(raw_dir, "%s.csv" % ds_name), "w", encoding="utf-8") as f:
        f.write("\n".join(s["smiles"] for s in sample_list) + "\n")

    # README
    with open(os.path.join(ds_dir, "%s_README" % ds_name.upper()), "w", encoding="utf-8") as f:
        f.write("%s 节点分类下游测试集(学术/社交图)\n" % ds_name)
        f.write("样本数: %d\n" % len(sample_list))
        f.write("task 数: %d (%s)\n" % (len(label_name), label_name))
        f.write("字段: node_feat=[n,512] float32 / edge_index / y=[1,T] one-hot / smiles=节点文本 / graph_domain=general\n")
        f.write("评测: downstream_test_lora.py --dataset %s --prompt_file prompt_downstream_academic.json --split random --transform_in_collator\n" % ds_name)

    print("  [done] %s -> %s" % (ds_name, os.path.abspath(ds_dir)))
    return len(sample_list)


def main():
    parser = argparse.ArgumentParser(description="节点分类下游测试数据集构建(cora/citeseer/wikics/instagram)")
    parser.add_argument("--data_dir", type=str, default=DATA_DIR)
    parser.add_argument("--output_dir", type=str, default=OUTPUT_DIR)
    parser.add_argument("--datasets", nargs="+", default=["cora", "citeseer", "wikics", "instagram"])
    parser.add_argument("--min_nodes", type=int, default=SAMPLER_CFG["min_nodes"])
    parser.add_argument("--max_nodes", type=int, default=SAMPLER_CFG["max_nodes"])
    parser.add_argument("--max_hop", type=int, default=SAMPLER_CFG["max_hop"])
    parser.add_argument("--visit_cap", type=int, default=SAMPLER_CFG["visit_cap"])
    args = parser.parse_args()

    stats = {}
    for ds_name in args.datasets:
        if ds_name not in DATASET_CFG:
            print("[warn] 未知数据集 %s, 跳过" % ds_name)
            continue
        try:
            sample_list, label_name = preprocess_single_dataset(ds_name, args)
            n = save_dataset(ds_name, sample_list, label_name, args)
            stats[ds_name] = {"samples": n, "tasks": len(label_name)}
            del sample_list
        except Exception:
            print("[error] %s 处理失败, 跳过: %s" % (ds_name, traceback.format_exc(limit=2)))

    with open(os.path.join(args.output_dir, "academic_test_stat.json"), "w", encoding="utf-8") as f:
        json.dump(stats, f, indent=2, ensure_ascii=False)
    print("\n==== 全部完成, 输出目录: %s ====" % os.path.abspath(args.output_dir))
    for k, v in stats.items():
        print("  %-12s %s" % (k, v))


if __name__ == "__main__":
    main()
