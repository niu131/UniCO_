#!/usr/bin/env python
# coding=utf-8
"""
pretrain_data_generation.py
===========================
将 data_academic 目录下的通用领域图数据集(arxiv_2023 / pubmed / reddit)处理为与
haitengzhao/molecule_property_instruction 相同列结构的"图+指令"预训练数据,
供 pretraining_unico_lora.py 直接使用, 实现分子图 + 通用领域图的混合预训练。

【与分子数据的关键差异 —— 通用图分支】
 1. 分子数据原始输入是 SMILES 字符串, 代码内部 smiles2graph 转 PyG Data;
    本脚本处理的 .pt 文件直接就是 PyG Data(x=[N,384] 连续浮点特征), 跳过
    smiles2graph 整套逻辑, 直接读取预处理好的 Data 对象。
 2. 分子节点特征为 9 维整型类别特征(截取前2维 → convert_to_single_emb 映射到
    512 维嵌入区间); 通用图节点特征为 384 维连续浮点, 【不截取、不映射】,
    仅零填充(pad)至 512 维对齐模型输入。
 3. 通用图无边特征: edge_feat 用 -1 占位([E,1]), 后续图变换由 collator 的
    通用图分支完成(dataloaders/graphormer_transform.py::general_graph_transform_tensor)。
 4. 每个样本带 graph_domain 列('general'/'molecule'), collator 与模型据此区分
    分子分支与通用分支(分子分支逻辑完全不变)。

【输出目录结构】(默认 ./processed_task_dataset)
    {ds}/                      各数据集的 DatasetDict{train, validation}(save_to_disk)
    combined/                  三数据集合并的 DatasetDict{train, validation}
    {ds}_train.parquet         单文件版本, 可直接 --train_file 传入预训练脚本
    {ds}_validation.parquet
    combined_train.parquet / combined_validation.parquet
    mixed/                     (仅 --include_hub_molecule 时) 分子+通用混合数据集
    dataset_stat.json          各数据集统计信息

【用法】
    python pretrain_data_generation.py                                  # 处理3个学术/社交数据集
    python pretrain_data_generation.py --include_hub_molecule           # 额外合并分子数据集(需联网)
    python pretrain_data_generation.py --datasets pubmed --max_nodes 64 # 只处理pubmed, 自定义子图上限

【预训练脚本对接】
    python pretraining_unico_lora.py ... --train_file processed_task_dataset/combined_train.parquet \
        --validation_file processed_task_dataset/combined_validation.parquet --transform_in_collator ...
    # 或使用 load_from_disk 路径(train_file 传目录, pretraining_unico_lora.py 已支持):
    python pretraining_unico_lora.py ... --train_file processed_task_dataset/combined ...
    # 注意: 通用图 dict 数据的图变换统一在 collator 完成, 必须加 --transform_in_collator。

【异常防护】
    - .pt 文件由 PyG 2.x 保存、环境为 PyG 1.7.2 时的兼容反序列化(缺类占位);
    - 空图/孤立节点子图(num_nodes<2)过滤; 采样异常逐节点 try/except 捕获;
    - 节点特征维度异常(>target 截断, <target 补零); 全零特征行置微小值(防被
      模型当作 padding 节点);
    - summary json 与 .pt 节点数不一致直接报错; 类别无正样本时跳过并告警。

不包含任何绘图相关代码。
"""

import argparse
import json
import os
import pickle
import sys
import traceback
from collections import deque

import numpy as np
import torch
from tqdm import tqdm

# ===================== 全局配置 =====================
DATA_DIR = "./data_academic"
OUTPUT_DIR = "./processed_task_dataset"

# 三个数据集的元信息(与 data_preprocess.py 的 DATASET_CFG 对齐)
DATASET_CFG = {
    "arxiv_2023": {
        "pt_file": "arxiv_2023.pt",
        "summary_json": "summary-arxiv_2023.json",
        "num_classes": 40,          # 实际存在38个类别(缺0与19), 缺失类别自动跳过
        "dataset_name": "arxiv_2023",
        "task_index": "academic_classification",
        "domain": "academic",
    },
    "pubmed": {
        "pt_file": "pubmed.pt",
        "summary_json": "summary-pubmed.json",
        "num_classes": 3,
        "dataset_name": "pubmed",
        "task_index": "diabetes_classification",
        "domain": "academic",
        "builtin_label_name": True,  # pubmed 自带 label_name
    },
    "reddit": {
        "pt_file": "reddit.pt",
        "summary_json": "summary-reddit.json",
        "num_classes": 2,
        "dataset_name": "reddit",
        "task_index": "user_popularity_classification",
        "domain": "social",
    },
}

# 子图采样超参(与 data_preprocess.py 的 SAMPLER_CFG 对齐)
SAMPLER_CFG = {
    "min_nodes": 25,        # 子图最少节点数(不足则继续向外扩跳)
    "max_nodes": 50,        # 子图最多节点数(BFS 距离序裁剪)
    "max_hop": 5,           # 最大扩展跳数
    "visit_cap": 5000,      # BFS 单次最多访问节点数(防止高连通图爆炸)
    "target_feat_dim": 512,  # 节点特征统一维度(零填充对齐模型输入)
}

VAL_RATIO = 0.05           # 验证集节点占比(按类别分层)
RANDOM_SEED = 42

# 指令 prompt 模板(默认英文, 与分子数据集指令语言/T5-small 词表一致)
PROMPT_TEMPLATES = {
    "en": "{summary}\nQuestion: Does the current node belong to {class_name}?",
    "zh": "{summary}\n问题：当前节点是否属于{class_name}？",
}

# 标签必须与分子数据集一致: 大写的 Yes/No(评估时按 tokenizer('Yes')/tokenizer('No')
# 的 token id 取 logit 计算 ROC-AUC, 小写会导致评估失效)
LABEL_POS, LABEL_NEG = "Yes", "No"


# ===================== .pt 兼容加载(处理 PyG 版本差异) =====================
class _CompatBase(object):
    """pickle 缺类时的占位类: 仅保存被 pickle 的 __dict__ 状态。"""

    def __repr__(self):
        return "%s(%s)" % (type(self).__name__, getattr(self, "__dict__", {}))


_COMPAT_CLASSES = {}


class _CompatUnpickler(pickle.Unpickler):
    def find_class(self, module, name):
        # 仅对 torch_geometric 内部类做缺类兼容(DataEdgeAttr/EdgeStorage 等 PyG2.x 类),
        # 其余类(含 torch.Tensor 的 persistent id 重建)走原生逻辑
        if module.startswith("torch_geometric"):
            try:
                return super().find_class(module, name)
            except (AttributeError, ImportError):
                key = module + "." + name
                if key not in _COMPAT_CLASSES:
                    _COMPAT_CLASSES[key] = type(name, (_CompatBase,), {"__module__": module})
                return _COMPAT_CLASSES[key]
        return super().find_class(module, name)


class _PatchedPickleModule(object):
    """暴露兼容 Unpickler 的 pickle 模块代理(torch.load 的 persistent_load 仍由 torch 注入)。"""

    Unpickler = _CompatUnpickler

    def __getattr__(self, item):
        return getattr(pickle, item)


def load_pt_file(pt_path):
    """加载 .pt 图数据文件。

    优先直接 torch.load(环境为 PyG 2.x 时); 失败则使用兼容 Unpickler
    (环境为 PyG 1.7.2 而文件由 PyG 2.x 保存时, 缺类以占位类替代)。
    """
    try:
        return torch.load(pt_path, map_location="cpu")
    except (AttributeError, ImportError, pickle.UnpicklingError) as e:
        print("[warn] 直接加载失败(%s), 尝试兼容反序列化: %s" % (type(e).__name__, pt_path))
        return torch.load(pt_path, map_location="cpu", pickle_module=_PatchedPickleModule())


def _field(data, key, default=None):
    """从 Data 对象取字段, 兼容 PyG 1.x / 2.x / 兼容占位对象三种存储结构。"""
    try:
        v = data[key]
        if v is not None:
            return v
    except Exception:
        pass
    if hasattr(data, key):
        return getattr(data, key)
    store = getattr(data, "_store", None)
    if store is not None:
        mapping = getattr(store, "_mapping", None)
        if mapping is not None and key in mapping:
            return mapping[key]
        if isinstance(store, dict) and key in store:
            return store[key]
    return default


# ===================== 子图采样 =====================
def build_adjacency(num_nodes, edge_index):
    """构建邻接表: adj_undir 用于 BFS 扩展(无向化), adj_dir 保留原始有向边。"""
    adj_undir = [[] for _ in range(num_nodes)]
    adj_dir = [[] for _ in range(num_nodes)]
    src, dst = edge_index[0].tolist(), edge_index[1].tolist()
    for u, v in zip(src, dst):
        if 0 <= u < num_nodes and 0 <= v < num_nodes:
            adj_dir[u].append(v)
            adj_undir[u].append(v)
            adj_undir[v].append(u)
    return adj_undir, adj_dir


def pad_or_trim_node_feat(node_feat, target_dim=SAMPLER_CFG["target_feat_dim"]):
    """节点特征统一为 [n, target_dim]: 不足补零, 超过截断(不截前2维、不做类别映射)。"""
    node_feat = torch.as_tensor(node_feat, dtype=torch.float32)
    if node_feat.dim() == 1:
        node_feat = node_feat.unsqueeze(1)
    cur = node_feat.size(-1)
    if cur > target_dim:
        node_feat = node_feat[:, :target_dim]
    elif cur < target_dim:
        node_feat = torch.nn.functional.pad(node_feat, (0, target_dim - cur), value=0.0)
    # 异常防护: 全零特征行会被模型 _valid_node_mask 误判为 padding 节点,
    # 置 1e-6 微扰保留其有效位(对特征数值影响可忽略)
    zero_rows = node_feat.abs().sum(dim=-1) == 0
    if zero_rows.any():
        node_feat[zero_rows, 0] = 1e-6
    return node_feat


def sample_one_ego_subgraph(center_node, adj_undir, adj_dir, node_feat,
                            min_nodes, max_nodes, max_hop, visit_cap):
    """对单个中心节点采样子图(BFS 逐层扩展, 语义与 k_hop_subgraph 一致但代价有界)。

    返回 smiles2graph 风格的紧凑图 dict(与分子数据 dict 键一致, 便于统一存储):
        {'edge_index': [2,E], 'node_feat': [n,512] float, 'edge_feat': [[-1.0]] 占位, 'num_nodes': n}
    失败返回 None(由调用方过滤)。
    """
    try:
        # ---- BFS 逐层扩展: 达到 min_nodes 或 max_hop 或访问上限时停止 ----
        visited = {center_node: 0}
        frontier = [center_node]
        hop = 0
        while frontier and hop < max_hop and len(visited) < min_nodes and len(visited) < visit_cap:
            nxt = []
            for u in frontier:
                for v in adj_undir[u]:
                    if v not in visited:
                        visited[v] = hop + 1
                        nxt.append(v)
                        if len(visited) >= visit_cap:
                            break
                if len(visited) >= visit_cap:
                    break
            frontier = nxt
            hop += 1

        # ---- 按 BFS 距离序裁剪到 max_nodes(稳定排序保持同距离的发现顺序) ----
        if len(visited) > max_nodes:
            subset = sorted(visited.keys(), key=lambda x: visited[x])[:max_nodes]
        else:
            subset = list(visited.keys())

        node_map = {old_id: new_id for new_id, old_id in enumerate(subset)}
        subset_set = set(subset)

        # ---- 用原始有向边提取子图边(保留原图方向, 与参考脚本一致) ----
        src, dst = [], []
        for u in subset:
            for v in adj_dir[u]:
                if v in subset_set:
                    src.append(node_map[u])
                    dst.append(node_map[v])

        sub_node_feat = pad_or_trim_node_feat(node_feat[torch.tensor(subset, dtype=torch.long)])

        graph_item = {
            "edge_index": [src, dst],  # [2, E]
            # 通用图无边特征: 以 -1.0 占位一列, 与 smiles2graph dict 键结构一致,
            # 真正特征由 collator 通用图分支处理(不参与分子式映射);
            # 【类型约束】保持 numpy float32(与分子转换分支一致, 保证混合数据集可拼接;
            # Python list 会被 arrow 推断为 float64, 与分子侧 float32 不兼容)
            "edge_feat": np.full((len(src), 1), -1.0, dtype=np.float32),
            # 【内存优化】node_feat 保持 numpy float32 数组(datasets 可直接序列化),
            # 避免 Python list 存储导致数十 GB 内存占用; 全量3数据集时按数据集逐个处理,
            # 峰值内存约 2-5GB/数据集
            "node_feat": np.ascontiguousarray(sub_node_feat.numpy(), dtype=np.float32),  # [n, 512] float32
            "num_nodes": int(len(subset)),
        }
        return graph_item
    except Exception:
        # 采样失败捕获: 记录异常并返回 None(调用方过滤, 不中断整体流程)
        print("[warn] 节点 %d 子图采样失败: %s" % (center_node, traceback.format_exc(limit=1)))
        return None


# ===================== 指令样本构造 =====================
def build_task_samples(center_node_ids, y, nodeid2graph, id2summary, label_name, task_id,
                       cfg, split_name, prompt_template, rng):
    """按任务(类别)构造正负 1:1 指令样本。

    center_node_ids: 该 split 内的候选节点(正/负均从中抽取, 保证 train/val 节点不重叠)
    """
    label_text = label_name[task_id]
    pos_ids = [n for n in center_node_ids
               if int(y[n]) == task_id and nodeid2graph.get(n) is not None]
    neg_ids = [n for n in center_node_ids
               if int(y[n]) != task_id and nodeid2graph.get(n) is not None]
    if len(pos_ids) == 0:
        print("  [warn] task %d (%s) 在 %s 无有效正样本, 跳过" % (task_id, label_text, split_name))
        return []
    if len(neg_ids) == 0:
        print("  [warn] task %d (%s) 在 %s 无有效负样本, 跳过" % (task_id, label_text, split_name))
        return []

    # 正负 1:1, 无放回; 负样本不足时取两者最小值(二分类 reddit 天然满足, 多分类负池充足)
    sample_size = min(len(pos_ids), len(neg_ids))
    rng.shuffle(pos_ids)
    rng.shuffle(neg_ids)
    pos_ids = pos_ids[:sample_size]
    neg_ids = neg_ids[:sample_size]

    samples = []
    for nid, label in zip(pos_ids, [LABEL_POS] * len(pos_ids)):
        prompt = prompt_template.format(summary=id2summary.get(nid, ""), class_name=label_text)
        samples.append({
            "graph": nodeid2graph[nid],
            "text": [prompt],  # 与分子数据集 text 列一致: sequence[string]
            "label": label,
            "dataset_name": cfg["dataset_name"],
            "task_index": cfg["task_index"],
            "molecule_index": str(nid),  # 分子数据集该列存分子ID; 通用图存源节点ID
            "split": split_name,
            "graph_domain": "general",  # 领域标记: collator/模型据此走通用图分支
        })
    for nid, label in zip(neg_ids, [LABEL_NEG] * len(neg_ids)):
        prompt = prompt_template.format(summary=id2summary.get(nid, ""), class_name=label_text)
        samples.append({
            "graph": nodeid2graph[nid],
            "text": [prompt],
            "label": label,
            "dataset_name": cfg["dataset_name"],
            "task_index": cfg["task_index"],
            "molecule_index": str(nid),
            "split": split_name,
            "graph_domain": "general",
        })
    return samples


def stratified_node_split(y, val_ratio, rng):
    """按类别分层划分 train/val 节点(每个类别至少留出验证节点数与比例的最大者)。"""
    classes = torch.unique(y).tolist()
    train_ids, val_ids = [], []
    for cls in classes:
        ids = (y == cls).nonzero(as_tuple=True)[0].tolist()
        rng.shuffle(ids)
        k = max(1, int(round(len(ids) * val_ratio))) if len(ids) >= 2 else 0
        val_ids.extend(ids[:k])
        train_ids.extend(ids[k:])
    rng.shuffle(train_ids)
    rng.shuffle(val_ids)
    return train_ids, val_ids


# ===================== 单数据集预处理主流程 =====================
def preprocess_single_dataset(ds_name, args):
    cfg = DATASET_CFG[ds_name]
    pt_path = os.path.join(args.data_dir, cfg["pt_file"])
    json_path = os.path.join(args.data_dir, cfg["summary_json"])

    print("\n==== %s: 加载数据 ====" % ds_name)
    data = load_pt_file(pt_path)
    x = torch.as_tensor(_field(data, "x"))
    edge_index = torch.as_tensor(_field(data, "edge_index"))
    y = torch.as_tensor(_field(data, "y"))
    if x is None or edge_index is None or y is None:
        raise ValueError("%s: .pt 缺少 x/edge_index/y 字段" % ds_name)
    num_nodes = x.size(0)
    if y.dim() > 1:
        y = y.squeeze(0)
    if y.size(0) != num_nodes:
        raise ValueError("%s: y 与 x 节点数不一致(%d vs %d)" % (ds_name, y.size(0), num_nodes))
    if edge_index.numel() > 0 and edge_index.size(0) != 2:
        raise ValueError("%s: edge_index 形状异常 %s" % (ds_name, tuple(edge_index.shape)))

    # label_name: pubmed 自带; 其余构造 "Class i"(与参考脚本一致)
    if cfg.get("builtin_label_name"):
        label_name = _field(data, "label_name")
        if label_name is None or len(label_name) != cfg["num_classes"]:
            label_name = ["Class %d" % i for i in range(cfg["num_classes"])]
            print("  [warn] %s 缺少有效 label_name, 使用默认 Class i" % ds_name)
    else:
        label_name = ["Class %d" % i for i in range(cfg["num_classes"])]
    label_name = list(label_name)

    # summary json: node_id -> summary, id 顺序与 .pt 行序严格对齐
    with open(json_path, "r", encoding="utf-8") as f:
        sum_list = json.load(f)
    id2summary = {item["id"]: item.get("summary", "") for item in sum_list}
    if len(id2summary) != num_nodes:
        raise ValueError("%s: summary json 节点数(%d)与 .pt 节点数(%d)不匹配!"
                         % (ds_name, len(id2summary), num_nodes))

    # ---- 全部节点各采样 1 次子图(与参考脚本一致) ----
    print("==== %s: 对全部 %d 节点采样子图 ====" % (ds_name, num_nodes))
    adj_undir, adj_dir = build_adjacency(num_nodes, edge_index)
    nodeid2graph = {}
    fail_cnt = 0
    isolated_cnt = 0
    for nid in tqdm(range(num_nodes), desc="采样子图"):
        g_item = sample_one_ego_subgraph(
            center_node=nid, adj_undir=adj_undir, adj_dir=adj_dir, node_feat=x,
            min_nodes=args.min_nodes, max_nodes=args.max_nodes, max_hop=args.max_hop,
            visit_cap=args.visit_cap)
        if g_item is None:
            fail_cnt += 1
            continue
        if g_item["num_nodes"] < 2:  # 孤立节点子图: 保留统计, 不进入正负样本池
            isolated_cnt += 1
        else:
            nodeid2graph[nid] = g_item
    print("  [统计] 采样失败 %d, 孤立子图(<2节点) %d, 有效子图 %d"
          % (fail_cnt, isolated_cnt, len(nodeid2graph)))

    # ---- 按类别分层划分 train/val 节点 ----
    rng = np.random.default_rng(args.seed)
    train_ids, val_ids = stratified_node_split(y, args.val_ratio, rng)
    print("  [统计] train 节点 %d, val 节点 %d" % (len(train_ids), len(val_ids)))

    prompt_template = PROMPT_TEMPLATES[args.prompt_lang]

    # ---- 按任务构造样本 ----
    train_samples, val_samples = [], []
    skipped = 0
    for task_id in range(cfg["num_classes"]):
        label_text = label_name[task_id]
        pos_total = int((y == task_id).sum())
        if pos_total == 0:
            print("  [warn] task %d (%s) 全数据集无正样本, 跳过" % (task_id, label_text))
            skipped += 1
            continue
        n_tr = build_task_samples(train_ids, y, nodeid2graph, id2summary, label_name, task_id,
                                  cfg, "train", prompt_template, rng)
        n_va = build_task_samples(val_ids, y, nodeid2graph, id2summary, label_name, task_id,
                                  cfg, "validation", prompt_template, rng)
        train_samples.extend(n_tr)
        val_samples.extend(n_va)

    # 释放大对象
    del nodeid2graph, adj_undir, adj_dir, id2summary
    print("  [统计] train 样本 %d, val 样本 %d, 跳过任务 %d" % (len(train_samples), len(val_samples), skipped))
    return train_samples, val_samples


# ===================== 分子数据集合并(可选) =====================
def build_hub_molecule_splits():
    """联网拉取 haitengzhao/molecule_property_instruction, 将 SMILES 转成图 dict
    (与通用图 dict 键结构、float32 特征类型一致), 供混合预训练拼接。
    """
    from datasets import load_dataset
    from ogb.utils import smiles2graph

    def convert_row(row):
        # 注意: 不能返回 None(datasets.map 会报错); 失败行以空图占位 + valid 标志过滤
        # node_feat/edge_feat 保持 numpy float32(与通用图 dict 类型一致, 保证可拼接)
        try:
            g = smiles2graph(row["graph"])
            graph_dict = {
                "edge_index": g["edge_index"].tolist(),
                "node_feat": np.ascontiguousarray(g["node_feat"], dtype=np.float32),
                "edge_feat": np.ascontiguousarray(g["edge_feat"], dtype=np.float32),
                "num_nodes": int(g["num_nodes"]),
            }
            valid = True
        except Exception as e:
            print("[warn] smiles2graph 失败: %s (%s)" % (row.get("molecule_index", "?"), e))
            graph_dict = {"edge_index": [[], []],
                          "node_feat": np.zeros((0, 9), dtype=np.float32),
                          "edge_feat": np.zeros((0, 3), dtype=np.float32),
                          "num_nodes": 0}
            valid = False
        return {
            "graph": graph_dict,
            "text": row["text"],
            "label": row["label"],
            "dataset_name": row["dataset_name"],
            "task_index": row["task_index"],
            "molecule_index": row["molecule_index"],
            "split": "train",
            "graph_domain": "molecule",
            "_valid": valid,
        }

    print("\n==== 联网加载分子数据集 haitengzhao/molecule_property_instruction ====")
    full = load_dataset("haitengzhao/molecule_property_instruction")
    print("  [info] chembl_pretraining SMILES → 图 dict 转换(数据量较大, 请耐心等待)...")
    train = full["chembl_pretraining"].map(
        convert_row, num_proc=max(1, os.cpu_count() // 2), remove_columns=["graph"])
    train = train.filter(lambda r: r["_valid"]).remove_columns("_valid")
    val = full["chembl_zero_shot"].map(
        convert_row, num_proc=max(1, os.cpu_count() // 2), remove_columns=["graph"])
    val = val.filter(lambda r: r["_valid"]).remove_columns("_valid")
    return train, val


# ===================== 保存输出 =====================
def save_dataset(ds_dir, train_samples, val_samples):
    """save_to_disk 保存 DatasetDict{train, validation}。"""
    from datasets import Dataset, DatasetDict
    train_ds = Dataset.from_list(train_samples) if train_samples else Dataset.from_dict({})
    val_ds = Dataset.from_list(val_samples) if val_samples else Dataset.from_dict({})
    DatasetDict({"train": train_ds, "validation": val_ds}).save_to_disk(ds_dir)
    return train_ds, val_ds


def main():
    parser = argparse.ArgumentParser(description="通用领域图数据 → UniCO 预训练数据生成")
    parser.add_argument("--data_dir", type=str, default=DATA_DIR)
    parser.add_argument("--output_dir", type=str, default=OUTPUT_DIR)
    parser.add_argument("--datasets", nargs="+", default=["arxiv_2023", "pubmed", "reddit"])
    parser.add_argument("--min_nodes", type=int, default=SAMPLER_CFG["min_nodes"])
    parser.add_argument("--max_nodes", type=int, default=SAMPLER_CFG["max_nodes"])
    parser.add_argument("--max_hop", type=int, default=SAMPLER_CFG["max_hop"])
    parser.add_argument("--visit_cap", type=int, default=SAMPLER_CFG["visit_cap"])
    parser.add_argument("--target_feat_dim", type=int, default=SAMPLER_CFG["target_feat_dim"])
    parser.add_argument("--val_ratio", type=float, default=VAL_RATIO)
    parser.add_argument("--seed", type=int, default=RANDOM_SEED)
    parser.add_argument("--prompt_lang", type=str, default="en", choices=["en", "zh"])
    parser.add_argument("--include_hub_molecule", action="store_true",
                        help="联网合并分子数据集(chembl_pretraining/chembl_zero_shot), 产出混合数据集")
    parser.add_argument("--skip_parquet", action="store_true", help="不输出单文件 parquet")
    args = parser.parse_args()

    for key in ("min_nodes", "max_nodes", "max_hop", "visit_cap", "target_feat_dim"):
        SAMPLER_CFG[key] = getattr(args, key)

    os.makedirs(args.output_dir, exist_ok=True)
    stats = {}

    # ---- 1. 通用领域图数据集处理(按数据集逐个处理并及时落盘, 控制峰值内存) ----
    sub_dirs = []
    for ds_name in args.datasets:
        if ds_name not in DATASET_CFG:
            print("[warn] 未知数据集 %s, 跳过" % ds_name)
            continue
        try:
            train_samples, val_samples = preprocess_single_dataset(ds_name, args)
        except Exception:
            print("[error] 数据集 %s 处理失败, 跳过: %s" % (ds_name, traceback.format_exc(limit=2)))
            continue
        stats[ds_name] = {"train": len(train_samples), "validation": len(val_samples)}

        # 按数据集分别保存 DatasetDict + 单文件 parquet, 保存后立即释放内存
        sub_dir = os.path.join(args.output_dir, ds_name)
        save_dataset(sub_dir, train_samples, val_samples)
        if not args.skip_parquet:
            from datasets import Dataset
            Dataset.from_list(train_samples).to_parquet(
                os.path.join(args.output_dir, "%s_train.parquet" % ds_name))
            Dataset.from_list(val_samples).to_parquet(
                os.path.join(args.output_dir, "%s_validation.parquet" % ds_name))
        sub_dirs.append(sub_dir)
        del train_samples, val_samples

    # ---- 2. 从已落盘分区 mmap 拼接 combined(避免全量样本驻留内存) ----
    if sub_dirs:
        from datasets import concatenate_datasets, load_from_disk, DatasetDict
        combined_dir = os.path.join(args.output_dir, "combined")
        parts_train = [load_from_disk(d)["train"] for d in sub_dirs]
        parts_val = [load_from_disk(d)["validation"] for d in sub_dirs]
        combined_train = concatenate_datasets(parts_train)
        combined_val = concatenate_datasets(parts_val)
        # 与 save_dataset 结构一致: DatasetDict{train, validation}, 可直接 load_from_disk
        DatasetDict({"train": combined_train, "validation": combined_val}).save_to_disk(combined_dir)
        if not args.skip_parquet:
            combined_train.to_parquet(os.path.join(args.output_dir, "combined_train.parquet"))
            combined_val.to_parquet(os.path.join(args.output_dir, "combined_validation.parquet"))
        stats["combined"] = {"train": len(combined_train), "validation": len(combined_val)}
        print("\n[done] 通用图数据集: train %d, validation %d" % (len(combined_train), len(combined_val)))
        gen_train_ds, gen_val_ds = combined_train, combined_val
    else:
        print("\n[warn] 未生成任何通用图样本, 请检查 --datasets 参数与数据文件")
        gen_train_ds, gen_val_ds = None, None

    # ---- 3. 可选: 合并分子数据集, 产出混合数据集 ----
    if args.include_hub_molecule:
        mol_train, mol_val = build_hub_molecule_splits()
        # 将通用图样本与分子样本(图 dict 键结构、float32 特征类型一致)拼接为混合数据集
        from datasets import concatenate_datasets
        parts_train = [mol_train] + ([gen_train_ds] if gen_train_ds is not None else [])
        parts_val = [mol_val] + ([gen_val_ds] if gen_val_ds is not None else [])
        mixed_train = concatenate_datasets(parts_train)
        mixed_val = concatenate_datasets(parts_val)
        mixed_dir = os.path.join(args.output_dir, "mixed")
        # 与 combined 一致: DatasetDict{train, validation}, 可直接 load_from_disk
        from datasets import DatasetDict
        DatasetDict({"train": mixed_train, "validation": mixed_val}).save_to_disk(mixed_dir)
        if not args.skip_parquet:
            mixed_train.to_parquet(os.path.join(args.output_dir, "mixed_train.parquet"))
            mixed_val.to_parquet(os.path.join(args.output_dir, "mixed_validation.parquet"))
        stats["mixed"] = {"train": len(mixed_train), "validation": len(mixed_val)}
        print("[done] 混合数据集(分子+通用图): train %d, validation %d" % (len(mixed_train), len(mixed_val)))

    # ---- 4. 统计落盘 ----
    with open(os.path.join(args.output_dir, "dataset_stat.json"), "w", encoding="utf-8") as f:
        json.dump(stats, f, indent=2, ensure_ascii=False)
    print("\n==== 全部完成, 输出目录: %s ====" % os.path.abspath(args.output_dir))
    for k, v in stats.items():
        print("  %-12s %s" % (k, v))


if __name__ == "__main__":
    main()
