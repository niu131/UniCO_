# UniCO: Dual-Cross Graph Foundation Models via Unified Covariance Operators

**UniCO** is a graph + instruction pretrained model. Built on a T5 language
backbone, it fuses graph nodes and text tokens inside every encoder layer, and
employs covariance operators and LoRA modules to jointly pretrain on molecular
graphs and general text-attributed graphs (academic / social networks) with a
unified "graph/subgraph + instruction" input format.



## 1. Download the Text-Attributed Graph Data

The raw text-attributed graph datasets (`arxiv_2023`, `pubmed`, `reddit` for
pretraining; `cora`, `citeseer`, `wikics`, `instagram` for downstream testing)
are packaged separately. Please download them first from:

[https://anonymous.4open.science/r/tag-7333/](https://anonymous.4open.science/r/tag-7333/)

and place the `data_academic` directory at the repository root.

## 2. Environment Setup

```bash
conda create -n env_gimlet python=3.7

source activate env_gimlet

pip3 install torch==1.9+cu111 torchaudio  -f https://download.pytorch.org/whl/cu111/torch_stable.html

wget https://data.pyg.org/whl/torch-1.9.0%2Bcu111/torch_scatter-2.0.9-cp37-cp37m-linux_x86_64.whl
pip install torch_scatter-2.0.9-cp37-cp37m-linux_x86_64.whl
wget https://data.pyg.org/whl/torch-1.9.0%2Bcu111/torch_sparse-0.6.12-cp37-cp37m-linux_x86_64.whl
pip install torch_sparse-0.6.12-cp37-cp37m-linux_x86_64.whl
wget https://data.pyg.org/whl/torch-1.9.0%2Bcu111/torch_cluster-1.5.9-cp37-cp37m-linux_x86_64.whl
pip install torch_cluster-1.5.9-cp37-cp37m-linux_x86_64.whl
wget https://data.pyg.org/whl/torch-1.9.0%2Bcu111/torch_spline_conv-1.2.1-cp37-cp37m-linux_x86_64.whl
pip install torch_spline_conv-1.2.1-cp37-cp37m-linux_x86_64.whl

pip install torch_geometric==1.7.2

git clone -b v4.28.1 https://github.com/huggingface/transformers

cd transformers
pip install --editable ./
python setup.py build_ext --inplace
cd ..

pip install datasets
pip install evaluate

pip install ogb
pip install spacy
pip install tqdm
pip install sklearn
pip install SentencePiece
pip install lmdb
pip install tensorboardX==2.4.1
pip install rdkit-pypi==2021.9.3
pip install dgl==0.7.2 -f https://data.dgl.ai/wheels/repo.html
pip install wandb
pip install networkx
pip install setuptools==59.5.0
pip install multiprocess
pip install Cython
pip install plotly
pip install commentjson
pip install pandas
pip install boto3
pip install chainer-chemistry
pip install subword-nmt
pip install pytorch_lightning==1.0
pip install plotly
pip install -U kaleido
```

## 3. Repository Structure

```
├── pretraining_unico.py                 # Pretraining entry (full model)
├── pretraining_unico_lora.py            # LoRA + new-module pretraining entry (main script)
├── continue_pretrain_for_downstream.py  # Continued pretraining from an existing checkpoint
├── downstream_test.py / downstream_test_lora.py   # Downstream zero/few-shot evaluation
├── pretrain_data_generation.py          # Text-attributed graph node-prediction pretraining data
├── pretrain_edge_prediction_generation.py  # Text-attributed graph link-prediction pretraining data
├── merge_pretrain_datasets.py           # Merge node + link pretraining datasets
├── build_semantic_refine_data.py        # Semantic-class-name node data (downstream refinement)
├── test_data_generation.py              # Downstream node classification test sets
├── test_edge_prediction_generation.py   # Downstream link prediction test sets
├── model/UniCO/                         # Model core (UniCOForConditionalGeneration / UniCOEncoderStack)
├── dataloaders/                         # Graph-text tokenizers / collators (molecule + text-attributed graph branches)
└── prompts/                             # Downstream instruction templates
```

## 4. Data Preparation

### 4.1 Molecule pretraining data

The molecular pretraining data is used directly from HuggingFace (no local preprocessing needed). These datasets are publicly available:[https://huggingface.co/datasets/haitengzhao/molecule_property_instruction](https://huggingface.co/datasets/haitengzhao/molecule_property_instruction)

```bash
# Pass the dataset name to --train_file / --validation_file:
#   haitengzhao/molecule_property_instruction
```

### 4.2 Process text-attributed graphs into the instruction format

The raw text-attributed graph files are PyG `Data` objects
(`data_academic/*.pt`, 384-dim continuous node features, no edge features).
The processing scripts perform BFS ego-subgraph sampling around every node /
node pair, zero-pad the node features to 512 dims (no truncation, no
molecule-style categorical mapping), construct the text instruction and
Yes/No label, and output a `DatasetDict` with the same column layout as the
molecule dataset (`graph / text / label / dataset_name / task_index /
molecule_index / split / graph_domain`).

```bash
# 4.2a Node-prediction pretraining data (arxiv_2023 / pubmed / reddit -> processed_task_dataset/)
python pretrain_data_generation.py
#     optional: --include_hub_molecule to merge the molecule dataset into one mixed dataset

# 4.2b Link-prediction pretraining data (3-hop joint subgraphs, 5-seed pos/neg sampling
#      -> processed_edge_prediction_dataset/)
python pretrain_edge_prediction_generation.py

# 4.2c Merge the two pretraining datasets (node + link -> processed_mixed_pretrain_dataset/)
python merge_pretrain_datasets.py

# 4.2d Downstream test sets (same format as property_data/bace, tox21, muv)
python test_data_generation.py                # cora / citeseer / wikics / instagram node classification
python test_edge_prediction_generation.py     # cora_edge / citeseer_edge / wikics_edge link prediction
```

## 5. Pretraining

### 5.1 Stage 1: molecular pretraining

```bash
CUDA_VISIBLE_DEVICES=0 python pretraining_unico.py \
  --model_name_or_path t5-small --tokenizer_name t5-small \
  --transformer_backbone unico --do_train \
  --train_file haitengzhao/molecule_property_instruction \
  --transform_in_collator --per_device_train_batch_size 64 \
  --gradient_accumulation_steps 1 --per_device_eval_batch_size 200 \
  --line_by_line --loss_reduction_method sentence \
  --save_steps 10000 --output_dir ckpts/unico_stage1
```

### 5.2 LoRA pretraining (molecules + new modules)

```bash
PYTHONUNBUFFERED=1 HF_ENDPOINT=https://hf-mirror.com CUDA_VISIBLE_DEVICES=0,1,2 \
python -m torch.distributed.launch --nproc_per_node=3 pretraining_unico_lora.py \
  --model_name_or_path ckpts/unico_stage1 --tokenizer_name t5-small \
  --transformer_backbone unico --do_train \
  --train_file haitengzhao/molecule_property_instruction \
  --validation_file haitengzhao/molecule_property_instruction \
  --transform_in_collator --per_device_train_batch_size 32 \
  --gradient_accumulation_steps 1 --per_device_eval_batch_size 100 \
  --line_by_line --loss_reduction_method sentence \
  --save_steps 10000 --eval_steps 10000 --logging_steps 10000 \
  --cov_max_order 5 --projection_resample_steps 50 --alpha_init 0.03 \
  --beta_init 0.03 --operator_scale 0.5 --cov_clip_value 8 --operator_dropout 0.05 \
  --lora_rank 16 --lora_alpha 32 --lora_dropout 0.05 \
  --lora_warm_lr 5e-5 --lora_lr 1e-4 --new_module_lr 5e-4 --new_module_main_lr 5e-5 \
  --new_module_final_lr 1e-5 --calibration_ratio 0.10 --stabilization_ratio 0.10 \
  --output_dir ckpts/unico_stage1_lora
```

### 5.3 Stage 2: joint pretraining on molecules + text-attributed graphs

Continue from the stage-1 checkpoint on the merged node + link pretraining
dataset. `--load_full_weights_from` fully restores the base backbone, the
trained LoRA adapters and the new modules (with a built-in NaN guard that
rejects diverged weights), and training continues with a fresh optimizer and a
conservative three-stage learning-rate schedule:

```bash
PYTHONUNBUFFERED=1 HF_ENDPOINT=https://hf-mirror.com CUDA_VISIBLE_DEVICES=0,1,2 \
python -m torch.distributed.launch --nproc_per_node=3 pretraining_unico_lora.py \
  --model_name_or_path ckpts/unico_stage1 --tokenizer_name t5-small \
  --transformer_backbone unico --do_train --do_eval \
  --evaluation_strategy steps --eval_steps 1000 \
  --train_file processed_mixed_pretrain_dataset \
  --validation_file processed_mixed_pretrain_dataset \
  --transform_in_collator --line_by_line \
  --load_full_weights_from ckpts/unico_stage1_lora/checkpoint-XXXXXX \
  --per_device_train_batch_size 32 --gradient_accumulation_steps 1 \
  --per_device_eval_batch_size 100 \
  --max_steps 10000 --save_steps 1000 --eval_steps 1000 --logging_steps 500 \
  --loss_reduction_method sentence \
  --cov_max_order 5 --projection_resample_steps 50 --alpha_init 0.03 --beta_init 0.03 \
  --operator_scale 0.5 --cov_clip_value 8 --operator_dropout 0.05 \
  --lora_rank 16 --lora_alpha 32 --lora_dropout 0.05 \
  --lora_warm_lr 1e-5 --lora_lr 5e-5 --lora_stabilization_lr 3e-5 --lora_final_lr 2e-5 \
  --new_module_lr 2e-4 --new_module_main_lr 2e-5 --new_module_stabilization_lr 1.5e-5 \
  --new_module_final_lr 1e-5 \
  --calibration_ratio 0.05 --stabilization_ratio 0.10 \
  --seed 42 \
  --output_dir ckpts/unico_stage2 --overwrite_output_dir
```

> Note: if a "NaN/Inf loss" warning appears during training (the `nan_steps`
> column in `pretrain_eval_log.tsv` becomes positive), the training has
> diverged — stop immediately and lower the learning rates.

## 6. Downstream Testing

### 6.1 Single dataset

```bash
python downstream_test_lora.py --dataset cora \
  --checkpoint ckpts/unico_stage2 \
  --model_name_or_path ckpts/unico_stage1 --tokenizer_name t5-small \
  --transformer_backbone unico \
  --prompt_file prompt_downstream_academic.json --split random \
  --transform_in_collator --zero_shot --batch_size 32 --task_policy traversal \
  --cov_max_order 5 --projection_resample_steps 50 --alpha_init 0.03 --beta_init 0.03 \
  --operator_scale 0.5 --cov_clip_value 8 --operator_dropout 0.05 \
  --loss_reduction_method sentence \
  --output_result_to_file results/unico_cora_results.csv
```

### 6.2 All datasets (node classification + link prediction, 7 datasets)

```bash
for ds in bace freesolv cora citeseer_edge; do
  python downstream_test_lora.py --dataset $ds \
    --checkpoint ckpts/unico_stage2 \
    --model_name_or_path ckpts/unico_stage1 --tokenizer_name t5-small \
    --transformer_backbone unico \
    --prompt_file prompt_downstream_academic.json --split random \
    --transform_in_collator --zero_shot --batch_size 32 --task_policy traversal \
    --cov_max_order 5 --projection_resample_steps 50 --alpha_init 0.03 --beta_init 0.03 \
    --operator_scale 0.5 --cov_clip_value 8 --operator_dropout 0.05 \
    --loss_reduction_method sentence \
    --output_result_to_file results/unico_all_results.csv
done

# Summary statistics (per dataset = mean of per-task test ROC-AUC)
python result_statistic.py --result_file_list results/unico_all_results.csv
```

> Notes: (1) the graph arguments in the evaluation command (cov_max_order etc.)
> must match those used in training; (2) legacy backbone keys and legacy class
> aliases are still accepted so that previously trained checkpoints load
> without conversion — new code should use `unico`.
