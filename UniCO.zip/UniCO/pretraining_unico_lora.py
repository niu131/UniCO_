#!/usr/bin/env python
# coding=utf-8
"""
LoRA pretraining entry for the modified UniCO encoder.

Key behavior:
1. Load the old/pretrained UniCO checkpoint with the current model class. Matching
   parameters are reused; new modules stay at their default initialization.
2. Freeze the reused backbone.
3. Inject LoRA adapters into T5 attention/FFN Linear layers.
4. Train LoRA parameters plus the new covariance/operator modules.
5. Use a three-stage per-group LR schedule with smooth transitions:
   - first 10%: LoRA warms up, new modules decay from a high calibration LR
   - middle 80%: both groups keep adapting with cosine decay
   - last 10%: both groups taper to their final LR
6. Keep only the top-K checkpoints according to eval ROC-AUC.
"""

import heapq
import logging
import math
import os
import shutil
import sys
from dataclasses import dataclass, field
from itertools import chain
from typing import Optional

import datasets
import torch
import torch.nn as nn
from datasets import DatasetDict, load_dataset
from transformers import (
    CONFIG_MAPPING,
    MODEL_FOR_MASKED_LM_MAPPING,
    AutoConfig,
    AutoModelForMaskedLM,
    AutoTokenizer,
    DataCollatorForLanguageModeling,
    HfArgumentParser,
    Trainer,
    TrainingArguments,
    is_torch_tpu_available,
    set_seed,
)
from transformers.trainer_utils import PREFIX_CHECKPOINT_DIR, get_last_checkpoint
from transformers.utils import check_min_version, send_example_telemetry
from transformers.utils.versions import require_version

from basic_pipeline import eval_result, load_graph_args
from dataloaders import graph_text_collator_dict, graph_text_tokenizer_dict, graphormer_transform_for_dataset, WrapDataset
from model import get_model

logger = logging.getLogger(__name__)
MODEL_CONFIG_CLASSES = list(MODEL_FOR_MASKED_LM_MAPPING.keys())
MODEL_TYPES = tuple(conf.model_type for conf in MODEL_CONFIG_CLASSES)

check_min_version("4.24.0.dev0")
require_version("datasets>=1.8.0", "To fix: pip install -r examples/pytorch/language-modeling/requirements.txt")
os.environ["WANDB_DISABLED"] = "true"


@dataclass
class ModelArguments:
    model_name_or_path: Optional[str] = field(default=None)
    model_type: Optional[str] = field(default=None, metadata={"help": "Model type: " + ", ".join(MODEL_TYPES)})
    config_overrides: Optional[str] = field(default=None)
    config_name: Optional[str] = field(default=None)
    tokenizer_name: Optional[str] = field(default=None)
    cache_dir: Optional[str] = field(default=None)
    use_fast_tokenizer: bool = field(default=True)
    model_revision: str = field(default="main")
    use_auth_token: bool = field(default=False)
    transformer_backbone: str = field(default="")
    attention_fasion: str = field(default="sequential")

    def __post_init__(self):
        if self.config_overrides is not None and (self.config_name is not None or self.model_name_or_path is not None):
            raise ValueError("--config_overrides can't be used with --config_name or --model_name_or_path")


@dataclass
class DataTrainingArguments:
    dataset_name: Optional[str] = field(default=None)
    dataset_config_name: Optional[str] = field(default=None)
    train_file: Optional[str] = field(default=None)
    validation_file: Optional[str] = field(default=None)
    overwrite_cache: bool = field(default=False)
    validation_split_percentage: Optional[int] = field(default=5)
    max_seq_length: Optional[int] = field(default=None)
    preprocessing_num_workers: Optional[int] = field(default=None)
    mlm_probability: float = field(default=0.15)
    line_by_line: bool = field(default=False)
    pad_to_max_length: bool = field(default=False)
    max_train_samples: Optional[int] = field(default=None)
    max_eval_samples: Optional[int] = field(default=None)
    rich_features: Optional[bool] = field(default=False)
    transform_in_collator: Optional[bool] = field(default=False)
    wrap_dataset: Optional[bool] = field(default=False)


@dataclass
class LoRATrainingArguments:
    lora_rank: int = field(default=16)
    lora_alpha: int = field(default=32)
    lora_dropout: float = field(default=0.05)
    lora_lr: float = field(default=1e-4)
    lora_warm_lr: float = field(default=5e-5)
    lora_stabilization_lr: float = field(default=5e-5)
    lora_final_lr: float = field(default=2e-5)
    new_module_lr: float = field(default=5e-4)
    new_module_main_lr: float = field(default=5e-5)
    new_module_stabilization_lr: float = field(default=2e-5)
    new_module_final_lr: float = field(default=1e-5)
    calibration_ratio: float = field(default=0.10)
    stabilization_ratio: float = field(default=0.10)
    top_k_checkpoints: int = field(default=10)
    eval_log_file: str = field(default="pretrain_eval_log.tsv")
    post_eval_checkpoints: bool = field(default=False)
    lora_targets: str = field(default="q,k,v,o,wi,wi_0,wi_1,wo")
    # 【新增: 接续预训练支持】从已训练完成的 LoRA checkpoint 目录完整恢复模型权重
    # (基础 backbone + LoRA A/B + 已训练的 new modules), 训练从全新 optimizer/
    # 调度器(global_step=0)开始, 便于为新领域数据设计独立的 LR 策略。
    # 不传该参数时行为与原先完全一致(分子预训练流程不受影响)。
    load_full_weights_from: Optional[str] = field(default=None)


class LoRALinear(nn.Module):
    def __init__(self, base_layer, rank=16, alpha=32, dropout=0.05):
        super().__init__()
        self.base_layer = base_layer
        self.rank = rank
        self.scaling = alpha / float(rank)
        self.dropout = nn.Dropout(dropout)
        self.lora_A = nn.Linear(base_layer.in_features, rank, bias=False)
        self.lora_B = nn.Linear(rank, base_layer.out_features, bias=False)
        nn.init.kaiming_uniform_(self.lora_A.weight, a=math.sqrt(5))
        nn.init.zeros_(self.lora_B.weight)
        for p in self.base_layer.parameters():
            p.requires_grad = False

    @property
    def weight(self):
        return self.base_layer.weight

    @property
    def bias(self):
        return self.base_layer.bias

    def forward(self, x):
        return self.base_layer(x) + self.lora_B(self.lora_A(self.dropout(x))) * self.scaling


def _get_parent_module(model, module_name):
    parent = model
    parts = module_name.split(".")
    for part in parts[:-1]:
        parent = getattr(parent, part)
    return parent, parts[-1]


def inject_lora(model, target_names, rank, alpha, dropout):
    target_names = set([x.strip() for x in target_names.split(",") if x.strip()])
    replaced = []
    for name, module in list(model.named_modules()):
        leaf = name.split(".")[-1]
        if leaf not in target_names:
            continue
        if not isinstance(module, nn.Linear):
            continue
        if not ("encoder.block" in name or "decoder.block" in name):
            continue
        parent, child_name = _get_parent_module(model, name)
        setattr(parent, child_name, LoRALinear(module, rank=rank, alpha=alpha, dropout=dropout))
        replaced.append(name)
    print("LoRA injected modules:", len(replaced))
    for name in replaced[:30]:
        print("  ", name)
    if len(replaced) > 30:
        print("  ...")
    return replaced


def freeze_backbone_train_lora_and_new_modules(model):
    for p in model.parameters():
        p.requires_grad = False

    new_module_keywords = [
        "alpha_raw",
        "beta_raw",
        "text_bias_raw",
        "edge_feature_embedding",
        "graph_input_norm",
        "text_input_norm",
        "edge_input_norm",
        "union_input_norm",
        "graph_node_feature",
    ]
    for name, p in model.named_parameters():
        if "lora_A" in name or "lora_B" in name or any(k in name for k in new_module_keywords):
            p.requires_grad = True

    trainable = [(n, p.numel()) for n, p in model.named_parameters() if p.requires_grad]
    print("Trainable tensors:", len(trainable), "Trainable params:", sum(x[1] for x in trainable))
    for n, _ in trainable[:60]:
        print("  trainable:", n)
    if len(trainable) > 60:
        print("  ...")


def split_trainable_params(model):
    lora_params, new_params = [], []
    for name, p in model.named_parameters():
        if not p.requires_grad:
            continue
        if "lora_A" in name or "lora_B" in name:
            lora_params.append(p)
        else:
            new_params.append(p)
    return lora_params, new_params


class ThreeStageLoRATrainer(Trainer):
    def __init__(self, *args, lora_train_args=None, **kwargs):
        self.lora_train_args = lora_train_args
        # NaN/Inf step 计数(供发散诊断)
        self.nan_loss_steps = 0
        super().__init__(*args, **kwargs)

    def training_step(self, model, inputs):
        loss = super().training_step(model, inputs)
        # 【NaN 检测】transformers fork 的 logging_nan_inf_filter 会把 NaN/Inf
        # loss 在日志里记成 0.0(掩盖发散), 这里显式告警与计数:
        # 一旦出现 NaN/Inf loss, 说明模型已发散(常见原因: 加载了发散的 checkpoint、
        # 学习率过大), 应立即终止并检查, 而不是"看似正常地"继续训练。
        if torch.isnan(loss) or torch.isinf(loss):
            self.nan_loss_steps += 1
            if self.nan_loss_steps <= 3 or self.nan_loss_steps % 200 == 0:
                logger.warning(
                    "检测到 NaN/Inf loss! (第 %d 次, step=%d)。日志中 train_loss=0.0 是 "
                    "logging_nan_inf_filter 的掩盖结果, 模型已发散, 请终止训练并检查: "
                    "1) 加载的 checkpoint 是否含 NaN; 2) 学习率是否过大",
                    self.nan_loss_steps, self.state.global_step)
        return loss

    def create_optimizer(self):
        if self.optimizer is None:
            lora_params, new_params = split_trainable_params(self.model)
            self.optimizer = torch.optim.AdamW(
                [
                    {"params": lora_params, "lr": self.lora_train_args.lora_lr, "name": "lora"},
                    {"params": new_params, "lr": self.lora_train_args.new_module_lr, "name": "new_modules"},
                ],
                betas=(0.9, 0.999),
                eps=1e-8,
                weight_decay=self.args.weight_decay,
            )
        return self.optimizer

    def create_scheduler(self, num_training_steps: int, optimizer=None):
        if self.lr_scheduler is None:
            optimizer = self.optimizer if optimizer is None else optimizer
            cal_steps = max(int(num_training_steps * self.lora_train_args.calibration_ratio), 1)
            stab_steps = max(int(num_training_steps * self.lora_train_args.stabilization_ratio), 1)
            main_end = max(num_training_steps - stab_steps, cal_steps + 1)

            def _clamp_progress(value):
                return min(max(value, 0.0), 1.0)

            def _cosine_lr(start_lr, end_lr, progress):
                progress = _clamp_progress(progress)
                factor = 0.5 * (1.0 + math.cos(math.pi * progress))
                return end_lr + (start_lr - end_lr) * factor

            def _lr_ratio(lr, base_lr):
                if base_lr == 0:
                    return 0.0
                return lr / base_lr

            def lora_lambda(step):
                args = self.lora_train_args
                if step < cal_steps:
                    lr = _cosine_lr(args.lora_warm_lr, args.lora_lr, step / max(cal_steps, 1))
                    return _lr_ratio(lr, args.lora_lr)
                if step < main_end:
                    progress = (step - cal_steps) / max(main_end - cal_steps, 1)
                    lr = _cosine_lr(args.lora_lr, args.lora_stabilization_lr, progress)
                    return _lr_ratio(lr, args.lora_lr)
                progress = (step - main_end) / max(num_training_steps - main_end, 1)
                lr = _cosine_lr(args.lora_stabilization_lr, args.lora_final_lr, progress)
                return _lr_ratio(lr, args.lora_lr)

            def new_lambda(step):
                args = self.lora_train_args
                base = args.new_module_lr
                if step < cal_steps:
                    lr = _cosine_lr(args.new_module_lr, args.new_module_main_lr, step / max(cal_steps, 1))
                    return _lr_ratio(lr, base)
                if step < main_end:
                    progress = (step - cal_steps) / max(main_end - cal_steps, 1)
                    lr = _cosine_lr(args.new_module_main_lr, args.new_module_stabilization_lr, progress)
                    return _lr_ratio(lr, base)
                progress = (step - main_end) / max(num_training_steps - main_end, 1)
                lr = _cosine_lr(args.new_module_stabilization_lr, args.new_module_final_lr, progress)
                return _lr_ratio(lr, base)

            self.lr_scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, [lora_lambda, new_lambda])
        return self.lr_scheduler

    def _save_checkpoint(self, model, trial, metrics=None):
        super()._save_checkpoint(model, trial, metrics=metrics)
        log_path = os.path.join(self.args.output_dir, self.lora_train_args.eval_log_file)
        lora_lr, new_module_lr = collect_group_lrs(self.optimizer)
        row = {
            "step": self.state.global_step,
            "epoch": "" if self.state.epoch is None else self.state.epoch,
            "train_loss": collect_logged_loss(self.state, self.state.global_step),
            "roc_auc": collect_logged_auc(self.state, self.state.global_step),
            "lora_lr": lora_lr,
            "new_module_lr": new_module_lr,
            # 【新增列】累计 NaN/Inf step 数(>0 表示训练已发散, 需立即处理)
            "nan_steps": self.nan_loss_steps,
        }
        append_pretrain_log(log_path, [row])


class TopKCheckpointCallback:
    pass


def build_unico_eval_fn(tokenizer, model_args):
    def _eval_fn(trainer):
        label_dict = {
            1: tokenizer.convert_tokens_to_ids(tokenizer.tokenize("Yes")),
            0: tokenizer.convert_tokens_to_ids(tokenizer.tokenize("No")),
            "invalid": [-100],
        }
        metrics_raw = eval_result(
            trainer.model,
            trainer.get_eval_dataloader(),
            label_dict,
            trainer.tokenizer,
            "cla",
            model_args.transformer_backbone,
        )
        return float(metrics_raw[0]["score"])

    return _eval_fn


def append_eval_log(log_path, rows):
    os.makedirs(os.path.dirname(log_path), exist_ok=True)
    write_header = not os.path.exists(log_path)
    with open(log_path, "a") as f:
        if write_header:
            f.write("checkpoint\tstep\tepoch\ttrain_loss\troc_auc\n")
        for row in rows:
            f.write("{checkpoint}\t{step}\t{epoch}\t{train_loss}\t{roc_auc}\n".format(**row))


def append_pretrain_log(log_path, rows):
    os.makedirs(os.path.dirname(log_path), exist_ok=True)
    write_header = not os.path.exists(log_path)
    with open(log_path, "a") as f:
        if write_header:
            f.write("step\tepoch\ttrain_loss\troc_auc\tlora_lr\tnew_module_lr\tnan_steps\n")
        for row in rows:
            f.write("{step}\t{epoch}\t{train_loss}\t{roc_auc}\t{lora_lr}\t{new_module_lr}\t{nan_steps}\n".format(**row))


def collect_logged_loss(trainer_state, step):
    selected = None
    for entry in trainer_state.log_history:
        if "loss" in entry and int(entry.get("step", -1)) <= int(step):
            selected = entry
    return selected.get("loss", "") if selected is not None else ""


def collect_logged_auc(trainer_state, step):
    selected = None
    for entry in trainer_state.log_history:
        if "eval_roc_auc" in entry and int(entry.get("step", -1)) <= int(step):
            selected = entry
        elif "roc_auc" in entry and int(entry.get("step", -1)) <= int(step):
            selected = entry
    if selected is None:
        return ""
    return selected.get("eval_roc_auc", selected.get("roc_auc", ""))


def collect_group_lrs(optimizer):
    lora_lr = ""
    new_module_lr = ""
    if optimizer is None:
        return lora_lr, new_module_lr
    for group in optimizer.param_groups:
        group_name = group.get("name", "")
        if group_name == "lora":
            lora_lr = group.get("lr", "")
        elif group_name == "new_modules":
            new_module_lr = group.get("lr", "")
    return lora_lr, new_module_lr


def evaluate_saved_checkpoints(trainer, tokenizer, model_args, output_dir, log_path):
    if trainer.eval_dataset is None:
        print("No eval dataset is available; skip checkpoint AUC logging.")
        return
    checkpoints = []
    if os.path.isdir(output_dir):
        for name in os.listdir(output_dir):
            if name.startswith(PREFIX_CHECKPOINT_DIR + "-"):
                try:
                    step = int(name.split("-")[-1])
                except ValueError:
                    continue
                checkpoints.append((step, os.path.join(output_dir, name)))
    checkpoints.sort()
    if not checkpoints:
        print("No checkpoints found under {}; skip checkpoint AUC logging.".format(output_dir))
        return

    rows = []
    eval_fn = build_unico_eval_fn(tokenizer, model_args)
    for step, ckpt_dir in checkpoints:
        print("Post-training eval checkpoint:", ckpt_dir)
        state_path = os.path.join(ckpt_dir, "pytorch_model.bin")
        if not os.path.isfile(state_path):
            print("Skip checkpoint without pytorch_model.bin:", ckpt_dir)
            continue
        state_dict = torch.load(state_path, map_location="cpu")
        missing_keys, unexpected_keys = trainer.model.load_state_dict(state_dict, strict=False)
        if missing_keys:
            print("  missing keys when loading checkpoint:", len(missing_keys))
        if unexpected_keys:
            print("  unexpected keys when loading checkpoint:", len(unexpected_keys))
        trainer.model.to(trainer.args.device)
        auc = eval_fn(trainer)
        rows.append({
            "checkpoint": ckpt_dir,
            "step": step,
            "epoch": "",
            "train_loss": collect_logged_loss(trainer.state, step),
            "roc_auc": auc,
        })
        append_eval_log(log_path, [rows[-1]])
        print("checkpoint {} roc_auc={:.6f}".format(step, auc))


def save_topk_checkpoint(trainer, tokenizer, output_dir, metric, top_heap, top_k):
    if metric is None:
        return
    os.makedirs(output_dir, exist_ok=True)
    step = trainer.state.global_step
    ckpt_dir = os.path.join(output_dir, "best_topk", "checkpoint-step{}-auc{:.6f}".format(step, float(metric)))
    trainer.save_model(ckpt_dir)
    tokenizer.save_pretrained(ckpt_dir)
    heapq.heappush(top_heap, (float(metric), ckpt_dir))
    while len(top_heap) > top_k:
        _, rm_dir = heapq.heappop(top_heap)
        if os.path.isdir(rm_dir):
            shutil.rmtree(rm_dir)


def load_raw_datasets(data_args, training_args, model_args):
    # 【新增: 本地预处理数据集支持】
    # pretrain_data_generation.py 输出的 DatasetDict 目录(save_to_disk 产物,
    # 含 train/validation split)可直接传入 --train_file, 例如:
    #   --train_file processed_task_dataset/combined --transform_in_collator
    # 其余加载路径(分子 hub 数据集 / json / csv / txt / parquet)行为不变。
    if data_args.train_file is not None and os.path.isdir(data_args.train_file):
        raw = datasets.load_from_disk(data_args.train_file)
        if "train" not in raw and "validation" not in raw:
            raise ValueError("本地数据集目录需包含 train/validation split: %s" % data_args.train_file)
        return raw

    if data_args.train_file == "haitengzhao/molecule_property_instruction" or data_args.validation_file == "haitengzhao/molecule_property_instruction":
        raw_datasets = {}
        dataset_full = load_dataset("haitengzhao/molecule_property_instruction")
        if training_args.do_train:
            raw_datasets["train"] = dataset_full["chembl_pretraining"]
        if training_args.do_eval:
            raw_datasets["validation"] = dataset_full["chembl_zero_shot"]
        return DatasetDict(raw_datasets)

    data_files = {}
    extension = None
    if data_args.train_file is not None:
        data_files["train"] = data_args.train_file
        extension = data_args.train_file.split(".")[-1]
    if data_args.validation_file is not None:
        data_files["validation"] = data_args.validation_file
        extension = data_args.validation_file.split(".")[-1]
    if extension == "txt":
        extension = "text"
    return load_dataset(extension, data_files=data_files, cache_dir=model_args.cache_dir,
                        use_auth_token=True if model_args.use_auth_token else None)


def main():
    parser = HfArgumentParser((ModelArguments, DataTrainingArguments, TrainingArguments, LoRATrainingArguments))
    model_args, data_args, training_args, lora_args, left = parser.parse_args_into_dataclasses(return_remaining_strings=True)
    model_args, graph_args = load_graph_args(model_args, left)

    send_example_telemetry("run_unico_lora_pretrain", model_args, data_args)
    logging.basicConfig(format="%(asctime)s - %(levelname)s - %(name)s - %(message)s",
                        datefmt="%m/%d/%Y %H:%M:%S", handlers=[logging.StreamHandler(sys.stdout)])
    log_level = training_args.get_process_log_level()
    logger.setLevel(log_level)
    datasets.utils.logging.set_verbosity(log_level)

    set_seed(training_args.seed)
    raw_datasets = load_raw_datasets(data_args, training_args, model_args)

    tokenizer_kwargs = {
        "cache_dir": model_args.cache_dir,
        "use_fast": model_args.use_fast_tokenizer,
        "revision": model_args.model_revision,
        "use_auth_token": True if model_args.use_auth_token else None,
    }
    tokenizer = AutoTokenizer.from_pretrained(model_args.tokenizer_name, **tokenizer_kwargs)

    if model_args.model_name_or_path and model_args.transformer_backbone != "":
        model = get_model(model_args, graph_args, tokenizer)
    elif model_args.model_name_or_path:
        config = AutoConfig.from_pretrained(model_args.config_name or model_args.model_name_or_path)
        model = AutoModelForMaskedLM.from_pretrained(model_args.model_name_or_path, config=config)
        model.resize_token_embeddings(len(tokenizer))
    else:
        config = CONFIG_MAPPING[model_args.model_type]()
        model = AutoModelForMaskedLM.from_config(config)

    inject_lora(model, lora_args.lora_targets, lora_args.lora_rank, lora_args.lora_alpha, lora_args.lora_dropout)
    freeze_backbone_train_lora_and_new_modules(model)

    # ---- 【新增: 接续预训练支持】----
    # 从已训练的 LoRA checkpoint 完整恢复权重(基础 backbone + 已训练的 LoRA A/B +
    # 已训练的 new modules), 而非从零初始化; 之后以全新 optimizer/调度器继续训练。
    # 注意: 模型结构必须与 checkpoint 一致(相同的 lora_rank/alpha/targets 与
    # graph 参数如 cov_max_order 等), 否则此处会打印 missing/unexpected 告警。
    # 不传 --load_full_weights_from 时跳过, 原分子预训练流程完全不变。
    if lora_args.load_full_weights_from is not None:
        ckpt_dir = lora_args.load_full_weights_from
        state_path = os.path.join(ckpt_dir, "pytorch_model.bin")
        if not os.path.isfile(state_path):
            raise FileNotFoundError("load_full_weights_from 目录缺少 pytorch_model.bin: %s" % ckpt_dir)
        state_dict = torch.load(state_path, map_location="cpu")
        # 【NaN 守卫】接续预训练必须从数值健康的 checkpoint 出发:
        # 若 checkpoint 本身含 NaN/Inf(训练发散产物), 直接报错终止,
        # 避免带着发散权重空转(该情况下 loss 恒为 NaN, 而 logging_nan_inf_filter
        # 会把日志记成 0.0, 掩盖发散事实)。提示用户改用最近一个干净 checkpoint。
        non_finite = [k for k, v in state_dict.items()
                      if v.is_floating_point() and not torch.isfinite(v).all()]
        if non_finite:
            raise ValueError(
                "load_full_weights_from 的 checkpoint 含 %d 个 NaN/Inf 张量, 该权重已发散不可用: %s\n"
                "请改用最近一个干净的 checkpoint(如发散前的上一个 save_steps 版本)" %
                (len(non_finite), str(non_finite[:8])))
        missing_keys, unexpected_keys = model.load_state_dict(state_dict, strict=False)
        logger.info("load_full_weights_from: %s" % ckpt_dir)
        logger.info("  missing keys: %d | unexpected keys: %d" % (len(missing_keys), len(unexpected_keys)))
        if missing_keys or unexpected_keys:
            logger.warning("  missing 示例: %s" % str(missing_keys[:5]))
            logger.warning("  unexpected 示例: %s" % str(unexpected_keys[:5]))

    if training_args.do_train:
        column_names = raw_datasets["train"].column_names
    else:
        column_names = raw_datasets["validation"].column_names
    text_column_name = "text" if "text" in column_names else column_names[0]

    if data_args.max_seq_length is None:
        max_seq_length = tokenizer.model_max_length
        if max_seq_length > 1024:
            max_seq_length = 1024
    else:
        max_seq_length = min(data_args.max_seq_length, tokenizer.model_max_length)

    if data_args.line_by_line:
        padding = "max_length" if data_args.pad_to_max_length else False
        if model_args.transformer_backbone != "":
            tokenize_function = lambda x: graph_text_tokenizer_dict[model_args.transformer_backbone](
                examples=x, tokenizer=tokenizer, text_column_name=text_column_name, padding=padding,
                max_seq_length=max_seq_length, rich_features=data_args.rich_features,
                transform_in_collator=(data_args.transform_in_collator or data_args.wrap_dataset)
            )
        else:
            def tokenize_function(examples):
                examples[text_column_name] = [line for line in examples[text_column_name] if len(line) > 0 and not line.isspace()]
                return tokenizer(examples[text_column_name], padding=padding, truncation=True,
                                 max_length=max_seq_length, return_special_tokens_mask=True)

        if data_args.max_train_samples is not None and training_args.do_train:
            raw_datasets["train"] = raw_datasets["train"].shuffle().select(range(min(len(raw_datasets["train"]), data_args.max_train_samples)))
        if data_args.max_eval_samples is not None and training_args.do_eval:
            raw_datasets["validation"] = raw_datasets["validation"].shuffle().select(range(min(len(raw_datasets["validation"]), data_args.max_eval_samples)))

        with training_args.main_process_first(desc="dataset map tokenization"):
            tokenized_datasets = raw_datasets.map(
                tokenize_function, batched=False, num_proc=data_args.preprocessing_num_workers,
                remove_columns=[text_column_name], load_from_cache_file=not data_args.overwrite_cache,
                desc="Running tokenizer on dataset line_by_line",
            )
        if data_args.wrap_dataset:
            def transform_func(examples):
                return graphormer_transform_for_dataset(examples=examples, rich_features=data_args.rich_features)
            if training_args.do_train:
                tokenized_datasets["train"] = WrapDataset(data=tokenized_datasets["train"], transform=transform_func)
            if training_args.do_eval:
                tokenized_datasets["validation"] = WrapDataset(data=tokenized_datasets["validation"], transform=transform_func)
    else:
        def tokenize_function(examples):
            return tokenizer(examples[text_column_name], return_special_tokens_mask=True)
        with training_args.main_process_first(desc="dataset map tokenization"):
            tokenized_datasets = raw_datasets.map(tokenize_function, batched=True,
                                                  num_proc=data_args.preprocessing_num_workers,
                                                  remove_columns=column_names,
                                                  load_from_cache_file=not data_args.overwrite_cache)
        def group_texts(examples):
            concatenated_examples = {k: list(chain(*examples[k])) for k in examples.keys()}
            total_length = len(concatenated_examples[list(examples.keys())[0]])
            if total_length >= max_seq_length:
                total_length = (total_length // max_seq_length) * max_seq_length
            return {k: [t[i: i + max_seq_length] for i in range(0, total_length, max_seq_length)] for k, t in concatenated_examples.items()}
        tokenized_datasets = tokenized_datasets.map(group_texts, batched=True,
                                                    num_proc=data_args.preprocessing_num_workers,
                                                    load_from_cache_file=not data_args.overwrite_cache)

    train_dataset = tokenized_datasets["train"] if training_args.do_train else None
    eval_dataset = tokenized_datasets["validation"] if training_args.do_eval else None

    pad_to_multiple_of_8 = data_args.line_by_line and training_args.fp16 and not data_args.pad_to_max_length
    if model_args.transformer_backbone != "":
        data_collator = graph_text_collator_dict[model_args.transformer_backbone](
            tokenizer=tokenizer, mlm_probability=data_args.mlm_probability,
            pad_to_multiple_of=8 if pad_to_multiple_of_8 else None,
            transform_in_collator=data_args.transform_in_collator, rich_features=data_args.rich_features)
    else:
        data_collator = DataCollatorForLanguageModeling(tokenizer=tokenizer, mlm_probability=data_args.mlm_probability,
                                                        pad_to_multiple_of=8 if pad_to_multiple_of_8 else None)

    training_args.remove_unused_columns = False
    trainer = ThreeStageLoRATrainer(
        model=model, args=training_args, train_dataset=train_dataset, eval_dataset=eval_dataset,
        tokenizer=tokenizer, data_collator=data_collator, lora_train_args=lora_args,
    )

    checkpoint = training_args.resume_from_checkpoint
    if checkpoint is None and os.path.isdir(training_args.output_dir) and training_args.do_train and not training_args.overwrite_output_dir:
        checkpoint = get_last_checkpoint(training_args.output_dir)

    if training_args.do_train:
        train_result = trainer.train(resume_from_checkpoint=checkpoint)
        trainer.log_metrics("train", train_result.metrics)
        trainer.save_metrics("train", train_result.metrics)
        trainer.save_state()
        if lora_args.post_eval_checkpoints:
            log_path = os.path.join(training_args.output_dir, lora_args.eval_log_file)
            evaluate_saved_checkpoints(trainer, tokenizer, model_args, training_args.output_dir, log_path)

    if training_args.do_eval and not training_args.do_train:
        metric = build_unico_eval_fn(tokenizer, model_args)(trainer)
        metrics = {"roc_auc": metric}
        trainer.log_metrics("eval", metrics)
        trainer.save_metrics("eval", metrics)

    trainer.create_model_card(finetuned_from=model_args.model_name_or_path, tasks="fill-mask")


if __name__ == "__main__":
    main()
