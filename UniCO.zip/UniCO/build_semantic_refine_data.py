#!/usr/bin/env python
# coding=utf-8
"""
build_semantic_refine_data.py
=============================
构建"语义类名"精炼预训练数据集: 把节点预测预训练样本的问题句从无语义的
"Class i" 改写为语义类名(与下游 cora/citeseer 等使用真实类名的评测协议对齐),
与边预测预训练样本合并, 供 continue_pretrain_for_downstream.py 精炼训练。

【动机】零样本节点分类中, "Class 3" 之类的无语义类名不跨数据集迁移(arxiv 的
Class 3 与 cora 的 Class 3 无任何关系), 模型无从判断; 而语义类名(如
"Neural Networks")让 T5 语言模型能利用摘要文本的主题信息回答归属问题,
与下游 cora/citeseer 真实类名的评测协议一致。

【类名映射】
 - arxiv_2023: OGBN-arxiv 标准 40 类 CS 领域名(cs.AI/cs.LG/...), 按 y 值索引;
 - pubmed: 糖尿病 3 类名(Diabetes Mellitus Experimental/Type1/Type2);
 - reddit: user popularity 2 类(popular users / less popular users);
 - 边预测样本原样保留(问题句已是语义化的 link existence)。

【输出】./processed_semantic_refine_dataset (DatasetDict{train, validation})
"""

import argparse
import json
import os
import re

from datasets import DatasetDict, concatenate_datasets, load_from_disk

NODE_DIR = "./processed_task_dataset/combined"
EDGE_DIR = "./processed_edge_prediction_dataset/combined"
OUTPUT_DIR = "./processed_semantic_refine_dataset"

# OGBN-arxiv 标准类别名(40 类, 索引即类别 id; arxiv_2023 缺失 id 0 与 19)
OGBN_ARXIV_CLASSES = [
    "cs.AI", "cs.AR", "cs.CC", "cs.CE", "cs.CG", "cs.CL", "cs.CR", "cs.CV",
    "cs.CY", "cs.DB", "cs.DC", "cs.DL", "cs.DM", "cs.DS", "cs.ET", "cs.FL",
    "cs.GL", "cs.GR", "cs.GT", "cs.HC", "cs.IR", "cs.IT", "cs.LG", "cs.LO",
    "cs.MA", "cs.MM", "cs.MS", "cs.NA", "cs.NE", "cs.NI", "cs.OS", "cs.PF",
    "cs.PL", "cs.RO", "cs.SC", "cs.SD", "cs.SE", "cs.SI", "cs.SY",
]
PUBMED_CLASSES = ["Diabetes Mellitus Experimental", "Diabetes Mellitus Type1",
                  "Diabetes Mellitus Type2"]
REDDIT_CLASSES = ["less popular users", "popular users"]

CLASS_NAME_TABLE = {
    "arxiv_2023": OGBN_ARXIV_CLASSES,
    "pubmed": PUBMED_CLASSES,
    "reddit": REDDIT_CLASSES,
}

QUESTION_RE = re.compile(r"\nQuestion: Does the current node belong to Class (\d+)\?$")


def rewrite_text(example):
    """把节点样本问题句 'belong to Class i?' 改写为语义类名。"""
    if example["dataset_name"] not in CLASS_NAME_TABLE:
        return example
    names = CLASS_NAME_TABLE[example["dataset_name"]]
    new_text = []
    for t in example["text"]:
        m = QUESTION_RE.search(t)
        if m:
            cls_id = int(m.group(1))
            class_name = names[cls_id] if cls_id < len(names) else "Class %d" % cls_id
            t = QUESTION_RE.sub("\nQuestion: Does the current node belong to %s?" % class_name, t)
        new_text.append(t)
    example["text"] = new_text
    return example


def main():
    parser = argparse.ArgumentParser(description="构建语义类名精炼预训练数据集")
    parser.add_argument("--node_dir", type=str, default=NODE_DIR)
    parser.add_argument("--edge_dir", type=str, default=EDGE_DIR)
    parser.add_argument("--output_dir", type=str, default=OUTPUT_DIR)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    node = load_from_disk(args.node_dir)
    edge = load_from_disk(args.edge_dir)

    # 节点样本: 问题句语义化
    node_train = node["train"].map(rewrite_text, batched=False, desc="语义化 train")
    node_val = node["validation"].map(rewrite_text, batched=False, desc="语义化 validation")
    for split, ds in [("train", node_train), ("validation", node_val)]:
        for i in range(2):
            print("[示例 %s] %s" % (split, ds[i]["text"][0].split("\n")[-1][:90]))

    # 与边预测样本合并(边样本原样)
    train = concatenate_datasets([node_train, edge["train"]]).shuffle(seed=args.seed)
    validation = concatenate_datasets([node_val, edge["validation"]]).shuffle(seed=args.seed)

    os.makedirs(args.output_dir, exist_ok=True)
    DatasetDict({"train": train, "validation": validation}).save_to_disk(args.output_dir)
    stats = {"train": len(train), "validation": len(validation),
             "node_train": len(node_train), "edge_train": len(edge["train"])}
    with open(os.path.join(args.output_dir, "dataset_stat.json"), "w", encoding="utf-8") as f:
        json.dump(stats, f, indent=2)
    print("完成: %s" % os.path.abspath(args.output_dir))
    print(stats)


if __name__ == "__main__":
    main()
