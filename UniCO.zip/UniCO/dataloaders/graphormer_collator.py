from torch_geometric.data.dataloader import Collater
import torch
from typing import Optional

from transformers import (
    DataCollatorForLanguageModeling,
)
from transformers.tokenization_utils_base import BatchEncoding

from collections.abc import Mapping, Sequence

import torch.utils.data
from torch.utils.data.dataloader import default_collate

from torch_geometric.data import Data, Batch
import numpy as np
from .graphormer_transform import graphormer_data_transform_tensor, general_graph_transform_tensor
from ogb.utils import smiles2graph
import time

def pad_1d_unsqueeze(x, padlen):
    x = x + 1  # pad id = 0
    xlen = x.size(0)
    if xlen < padlen:
        new_x = x.new_zeros([padlen], dtype=x.dtype)
        new_x[:xlen] = x
        x = new_x
    return x.unsqueeze(0)


def pad_2d_unsqueeze(x, padlen):
    x = x + 1  # pad id = 0
    xlen, xdim = x.size()
    if xlen < padlen:
        new_x = x.new_zeros([padlen, xdim], dtype=x.dtype)
        new_x[:xlen, :] = x
        x = new_x
    return x.unsqueeze(0)


def pad_2d_unsqueeze_float(x, padlen):
    # 【通用图分支】连续浮点节点特征零填充, 不做 +1 平移
    # (分子整型类别特征依赖 +1 平移把 padding 让给 id=0; 浮点特征 +1 会破坏数值)
    xlen, xdim = x.size()
    if xlen < padlen:
        new_x = x.new_zeros([padlen, xdim], dtype=x.dtype)
        new_x[:xlen, :] = x
        x = new_x
    return x.unsqueeze(0)


def pad_attn_bias_unsqueeze(x, padlen):
    xlen = x.size(0)
    if xlen < padlen:
        new_x = x.new_zeros([padlen, padlen], dtype=x.dtype).fill_(float("-inf"))
        new_x[:xlen, :xlen] = x
        new_x[xlen:, :xlen] = 0
        x = new_x
    return x.unsqueeze(0)


def pad_edge_type_unsqueeze(x, padlen, feat_dim=None):
    # feat_dim: 【通用图分支】混合批次时按批内最大末维对齐(分子边特征2维, 通用占位1维)
    xlen = x.size(0)
    if feat_dim is not None and x.size(-1) < feat_dim:
        x = torch.nn.functional.pad(x, (0, feat_dim - x.size(-1)), value=0)
    if xlen < padlen:
        new_x = x.new_zeros([padlen, padlen, x.size(-1)], dtype=x.dtype)
        new_x[:xlen, :xlen, :] = x
        x = new_x
    return x.unsqueeze(0)


def pad_spatial_pos_unsqueeze(x, padlen):
    x = x + 1
    xlen = x.size(0)
    if xlen < padlen:
        new_x = x.new_zeros([padlen, padlen], dtype=x.dtype)
        new_x[:xlen, :xlen] = x
        x = new_x
    return x.unsqueeze(0)


def pad_3d_unsqueeze(x, padlen1, padlen2, padlen3):

    x = x + 1
    xlen1, xlen2, xlen3, xlen4 = x.size()
    if xlen1 < padlen1 or xlen2 < padlen2 or xlen3 < padlen3:
        # new_x = x.new_zeros([padlen1, padlen2, padlen3, xlen4], dtype=x.dtype)
        # new_x[:xlen1, :xlen2, :xlen3, :] = x
        # x = new_x
        x = torch.nn.functional.pad(
            x,
            pad=(0,0, 0, padlen3 - xlen3,0, padlen2 - xlen2,0, padlen1 - xlen1, ),
            mode='constant',
            value=0
        )

    return x.unsqueeze(0)

def pad_3d_sequences(xs, padlen1, padlen2, padlen3, feat_dim=None):
    # feat_dim: 【通用图分支】混合批次时按批内最大末维对齐(不传时沿用原逻辑)
    feat_dim = feat_dim if feat_dim is not None else xs[0].shape[-1]
    result=torch.zeros([len(xs),padlen1,padlen2,padlen3,feat_dim], dtype=xs[0].dtype)
    for i,x in enumerate(xs):
        result[i,:x.shape[0], :x.shape[1], :x.shape[2], :x.shape[-1]]=x+1
    return result


def pad_in_edge_features(xs, padlen_node, padlen_edge, feat_dim=None):
    # feat_dim: 【通用图分支】混合批次时按批内最大末维对齐(不传时沿用原逻辑)
    feat_dim = feat_dim if feat_dim is not None else xs[0].shape[-1]
    result = torch.zeros([len(xs), padlen_node, padlen_edge, feat_dim], dtype=xs[0].dtype)
    for i, x in enumerate(xs):
        result[i, :x.shape[0], :x.shape[1], :x.shape[-1]] = x
    return result


def pad(encoded_inputs,
        pad_token_id,
        pad_token_type_id,
        max_length: Optional = None,
        pad_to_multiple_of: Optional = None,
        return_attention_mask: Optional = None,
        padding_side='right',
        ):
    if return_attention_mask is None:
        return_attention_mask = "attention_mask" in encoded_inputs

    required_input = encoded_inputs[list(encoded_inputs.keys())[0]]


    if max_length is not None and pad_to_multiple_of is not None and (max_length % pad_to_multiple_of != 0):
        max_length = ((max_length // pad_to_multiple_of) + 1) * pad_to_multiple_of

    needs_to_be_padded =  len(required_input) != max_length

    # Initialize attention mask if not present.
    if return_attention_mask and "attention_mask" not in encoded_inputs:
        encoded_inputs["attention_mask"] = [1] * len(required_input)

    if needs_to_be_padded:
        difference = max_length - len(required_input)

        if padding_side == "right":
            if return_attention_mask:
                encoded_inputs["attention_mask"] = encoded_inputs["attention_mask"] + [0] * difference
            if "token_type_ids" in encoded_inputs:
                encoded_inputs["token_type_ids"] = (
                        encoded_inputs["token_type_ids"] + [pad_token_type_id] * difference
                )
            if "special_tokens_mask" in encoded_inputs:
                encoded_inputs["special_tokens_mask"] = encoded_inputs["special_tokens_mask"] + [1] * difference
            if "answer_mask" in encoded_inputs:
                encoded_inputs["answer_mask"] = encoded_inputs["answer_mask"] + [0] * difference
            if "input_ids" in encoded_inputs:
                encoded_inputs['input_ids'] = encoded_inputs['input_ids'] + [pad_token_id] * difference
            if "labels" in encoded_inputs:
                encoded_inputs['labels'] = encoded_inputs['labels'] + [-100] * difference #-100 can makesure that generation loss will not consider padded position
            if 'decoder_attention_mask' in encoded_inputs:
                encoded_inputs['decoder_attention_mask'] = encoded_inputs['decoder_attention_mask']+[0]*difference


        else:
            raise ValueError("Invalid padding strategy:" + str(padding_side))

    return encoded_inputs

def padding(encoded_inputs,
        pad_token_id,
        pad_token_type_id,
        max_length: Optional = None,
        pad_to_multiple_of: Optional = None,
        return_attention_mask: Optional = None):
    if isinstance(encoded_inputs, (list, tuple)) and isinstance(encoded_inputs[0], Mapping):
        encoded_inputs = {key: [example[key] for example in encoded_inputs] for key in encoded_inputs[0].keys()}


    required_input = encoded_inputs[list(encoded_inputs.keys())[0]]
    if required_input and not isinstance(required_input[0], (list, tuple)):
        encoded_inputs = pad(
            encoded_inputs,
            pad_token_id,
            pad_token_type_id,
            max_length=max_length,
            pad_to_multiple_of=pad_to_multiple_of,
            return_attention_mask=return_attention_mask,
        )
        return BatchEncoding(encoded_inputs, tensor_type='pt')

    batch_size = len(required_input)
    max_length = max(len(inputs) for inputs in required_input)
    # padding_strategy = PaddingStrategy.MAX_LENGTH


    batch_outputs = {}
    for i in range(batch_size):
        inputs = dict((k, v[i]) for k, v in encoded_inputs.items())
        outputs = pad(
            inputs,
            pad_token_id,
            pad_token_type_id,
            max_length=max_length,
            pad_to_multiple_of=pad_to_multiple_of,
            return_attention_mask=return_attention_mask,
        )

        for key, value in outputs.items():
            if key not in batch_outputs:
                batch_outputs[key] = []
            batch_outputs[key].append(value)
    return BatchEncoding(batch_outputs, tensor_type='pt')


def _has_attr(item, key):
    try:
        return key in item
    except Exception:
        return hasattr(item, key)


def _detect_general_graph(item, domain):
    # 【通用图分支判定】
    # 1) 显式 graph_domain 列优先(pretrain_data_generation.py 写入 'general'/'molecule',
    #    混合数据集中分子样本被转换为 float node_feat 后 dtype 不再可区分, 必须靠该列);
    # 2) 无该列时按特征 dtype 兜底: 通用图 node_feat 为连续浮点,
    #    分子图(smiles2graph 产物) node_feat 恒为整型类别特征。
    if domain == 'general':
        return True
    if domain == 'molecule':
        return False
    if _has_attr(item, 'node_feat') and item.node_feat.is_floating_point():
        return True
    return False


def collator_graph_data(items, max_node=512, multi_hop_max_dist=20, spatial_pos_max=20,
                        transform_in_collator=False, include_y=False, rich_features=False,
                        graph_domains=None):
    # graph_domains: 与 items 等长的领域标记列表('general'/'molecule'/None), 由上层 collator
    # 从样本的 graph_domain 列传入; 分子数据无该列时为 None, 走 dtype 兜底判定。
    items_new = []
    ys = []

    for idx, item in enumerate(items):
        domain = graph_domains[idx] if graph_domains is not None else None

        if transform_in_collator:
            if isinstance(item, str):
                item = smiles2graph(item)

        if include_y:
            ys.append(item.y)
        item_new = Data()
        if isinstance(item, Data):
            for key in item.keys:
                # 【通用图下游分支】字符串标记字段(如 graph_domain='general')不参与批处理, 跳过;
                # 分子数据无字符串字段, 行为不变
                if isinstance(item[key], str):
                    continue
                item_new[key] = torch.tensor(item[key]) if (not isinstance(item[key], torch.Tensor)) else item[key]
        else:
            for key in item.keys():
                if isinstance(item[key], str):
                    continue
                item_new[key] = torch.tensor(item[key]) if (not isinstance(item[key], torch.Tensor)) else item[key]

        is_general = _detect_general_graph(item_new, domain)
        if is_general:
            # 【通用图分支】跳过分子式变换, 走连续特征变换(不截取/不映射, 无边特征占位)
            item_new = general_graph_transform_tensor(item_new)
        elif transform_in_collator:
            # 分子分支: 原逻辑完全不变
            item_new = graphormer_data_transform_tensor(item_new, rich_features)
        items_new.append((item_new, is_general))

    items = [(it, is_gen) for (it, is_gen) in items_new if it is not None and it['x'].size(0) <= max_node]
    has_general = any(is_gen for _, is_gen in items)

    rows = []
    for it, is_gen in items:
        # 通用图样本无 in_edge_feats(模型端自动禁用边协方差), 以全零占位保证批内形状一致
        in_edge = it.in_edge_feats if _has_attr(it, 'in_edge_feats') else \
            torch.zeros([it.x.size(0), 1, 1], dtype=torch.long)
        # 通用图样本不参与分子 GraphNodeFeature 的度编码: 存 -1,
        # 经 pad_1d_unsqueeze 的 +1 平移后为 0(=padding, 度嵌入输出零向量)
        in_deg = it.in_degree if not is_gen else torch.full_like(it.in_degree, -1)
        rows.append((it, is_gen, in_deg, in_edge))

    attn_biases = [r[0].attn_bias for r in rows]
    attn_edge_types = [r[0].attn_edge_type for r in rows]
    spatial_poses = [r[0].spatial_pos for r in rows]
    in_degrees = [r[2] for r in rows]
    out_degrees = [r[2] for r in rows]
    xs = [r[0].x for r in rows]
    edge_inputs = [r[0].edge_input[:, :, :multi_hop_max_dist, :] for r in rows]
    in_edge_feats = [r[3] for r in rows]

    for idx, _ in enumerate(attn_biases):
        attn_biases[idx][1:, 1:][spatial_poses[idx] >= spatial_pos_max] = float("-inf")

    max_node_num = max(i.size(0) for i in xs)
    max_dist = max(i.size(-2) for i in edge_inputs)
    max_in_edge_num = max(i.size(1) for i in in_edge_feats)

    # 【通用图分支】混合批次: 分子边特征末维(2/3)与通用图占位末维(1)按批内最大值对齐
    if has_general:
        feat_edge_type = max(i.size(-1) for i in attn_edge_types)
        feat_edge_input = max(i.size(-1) for i in edge_inputs)
        feat_in_edge = max(i.size(-1) for i in in_edge_feats)
    else:
        feat_edge_type = feat_edge_input = feat_in_edge = None

    # ---- 节点特征批处理: 分子(整型,+1平移) 与 通用(浮点,零填充) 双张量结构 ----
    if not has_general:
        # 纯分子批次: 完全沿用原逻辑
        x = torch.cat([pad_2d_unsqueeze(i, max_node_num) for i in xs])
        x_float = None
    else:
        # 含通用图批次: x 仍为整型(分子样本有效, 通用样本全零行),
        # x_float 为连续特征(通用样本有效, 分子样本全零行); 模型端按字段有无分支
        F_mol = max((i.size(1) for i, is_gen in zip(xs, [r[1] for r in rows]) if not is_gen), default=1)
        F_gen = max((i.size(1) for i, is_gen in zip(xs, [r[1] for r in rows]) if is_gen), default=1)
        x_rows, x_float_rows = [], []
        for i, is_gen in zip(xs, [r[1] for r in rows]):
            if is_gen:
                x_float_rows.append(pad_2d_unsqueeze_float(i, max_node_num))
                x_rows.append(i.new_zeros([1, max_node_num, F_mol], dtype=torch.long))
            else:
                x_rows.append(pad_2d_unsqueeze(i, max_node_num))
                x_float_rows.append(i.new_zeros([1, max_node_num, F_gen], dtype=torch.float32))
        x = torch.cat(x_rows, 0)
        x_float = torch.cat(x_float_rows, 0)

    edge_input = pad_3d_sequences(edge_inputs, max_node_num, max_node_num, max_dist, feat_edge_input)
    in_edge_feats = pad_in_edge_features(in_edge_feats, max_node_num, max_in_edge_num, feat_in_edge)

    attn_bias = torch.cat(
        [pad_attn_bias_unsqueeze(i, max_node_num + 1) for i in attn_biases]
    )

    attn_edge_type = torch.cat(
        [pad_edge_type_unsqueeze(i, max_node_num, feat_edge_type) for i in attn_edge_types]
    )

    spatial_pos = torch.cat(
        [pad_spatial_pos_unsqueeze(i, max_node_num) for i in spatial_poses]
    )

    in_degree = torch.cat([pad_1d_unsqueeze(i, max_node_num) for i in in_degrees])

    result = Data(
        # idx=torch.LongTensor(idxs),
        attn_bias=attn_bias,
        attn_edge_type=attn_edge_type,
        spatial_pos=spatial_pos,
        in_degree=in_degree,
        out_degree=in_degree,  # for undirected graph
        x=x,
        edge_input=edge_input,
        in_edge_feats=in_edge_feats,
    )
    if include_y:
        result.y = torch.cat(ys)
    if x_float is not None:
        # 【通用图分支】连续节点特征张量, 模型端据此走通用特征投影
        result.x_float = x_float
    return result



class CollatorForGraphormer(Collater):
    def __init__(self, **kwargs):
        self.transform_in_collator = kwargs.pop('transform_in_collator')
        self.include_y = kwargs.pop('include_y')
        self.rich_features = kwargs.pop('rich_features')
        try:
            super().__init__([],[])
        except:
            print('torch_geometric version is too low. Collater only accept one parameter for initialization')
            super().__init__([])

    def collate(self, batch):
        graph_batch = collator_graph_data(batch, transform_in_collator=self.transform_in_collator,
                                          include_y=self.include_y, rich_features=self.rich_features)
        return graph_batch


class CollaterForGraphormerMultiTask(CollatorForGraphormer):
    def collate(self, examples):
        graph_batch=[]
        labels_cla_batch=[]
        labels_reg_batch=[]
        for example_data in examples:
            graph_data=example_data['graph']
            graph_batch.append(graph_data)
            labels_cla_batch.append(example_data['label_cla'])
            labels_reg_batch.append(example_data['label_reg'])

        graph_batch = collator_graph_data(graph_batch, transform_in_collator=self.transform_in_collator,
                                          include_y=self.include_y, rich_features=self.rich_features)
        label_cla = torch.tensor(labels_cla_batch)
        label_reg = torch.tensor(labels_reg_batch)

        return {'graph':graph_batch,'label_cla':label_cla,'label_reg':label_reg}