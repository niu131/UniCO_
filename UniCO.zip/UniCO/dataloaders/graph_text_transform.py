import torch
import numpy as np
# from . import algos

import pyximport
from ogb.utils import smiles2graph

pyximport.install(setup_args={"include_dirs": np.get_include()})
from .graphormer_transform import graphormer_data_transform
import numbers
# @torch.jit.script
def convert_to_single_emb(x, offset: int = 512):
    feature_num = x.shape[1] if len(x.shape) > 1 else 1
    feature_offset = (1 + np.arange(0, feature_num * offset, offset)).astype("long")
    x = x + feature_offset
    return x



def gin_add_prompt_conditional_generation_transform_single(data,data_label,input_ids,attention_mask,label_dict,**kwargs):
    if float(data_label) in label_dict:
        label=label_dict[float(data_label)]
    else:
        label=label_dict['invalid']

    input_ids_out=input_ids
    attention_mask_out=attention_mask
    return {'graph': data,
            'input_ids': input_ids_out,
            'attention_mask': attention_mask_out,
            # 'special_tokens_mask': special_tokens_mask,
            'labels': label,
            }


def unico_add_prompt_conditional_generation_transform_single(data, data_label, input_ids, attention_mask, label_dict, transform_in_collator, rich_features=False, tokenizer=None, generaltive_label=False, **kwargs):
    if generaltive_label:
        if isinstance(data_label,torch.Tensor) or isinstance(data_label, numbers.Number):
            label=tokenizer(str(round(float(data_label), 2)))
        else:
            label = tokenizer(str(data_label))
    else:
        if float(data_label) in label_dict:
            label=label_dict[float(data_label)]
        else:
            label=label_dict['invalid']

    input_ids_out=input_ids
    attention_mask_out=attention_mask

    if not transform_in_collator:
        # 分子分支: SMILES 图(x/edge_attr 类别特征)做原有变换;
        # 【通用图下游分支】学术/社交图(node_feat 连续特征, 无 x/edge_attr)原样透传,
        # 变换由 collator 的通用图分支完成
        if hasattr(data, 'x') and hasattr(data, 'edge_attr'):
            data= graphormer_data_transform(data, rich_features=rich_features)

    # 【通用图下游分支】样本携带图域标记 graph_domain='general' 时, 将样本级文本
    # (节点/节点对的描述, 存在 smiles 属性中) tokenize 后前置到静态指令之前,
    # 与预训练指令 "<样本描述>\nQuestion: ..." 的格式一致;
    # 分子数据无 graph_domain 属性, 原逻辑完全不变。
    sample_domain = None
    try:
        sample_domain = data.graph_domain
    except Exception:
        sample_domain = None
    if sample_domain == 'general' and tokenizer is not None:
        # 样本文本优先取 raw_texts(加载器只删除 smiles, raw_texts 在 transform 阶段仍可用;
        # 两种字段均由 test_data_generation.py / test_edge_prediction_generation.py 写入)
        sample_text = None
        for key in ("raw_texts", "smiles"):
            try:
                sample_text = data[key]
                if sample_text:
                    break
            except Exception:
                sample_text = None
        # InMemoryDataset 按切片取出的是单元素列表, 解包为字符串
        if isinstance(sample_text, (list, tuple)):
            sample_text = sample_text[0] if len(sample_text) > 0 else None
        if sample_text:
            text_tok = tokenizer(sample_text, truncation=True, max_length=300)
            text_ids = [t for t in text_tok['input_ids'] if t != tokenizer.eos_token_id]
            input_ids_out = text_ids + input_ids_out
            attention_mask_out = [1] * len(text_ids) + attention_mask_out
    if generaltive_label:
        return {'graph': data,
            'input_ids': input_ids_out,
            'attention_mask': attention_mask_out,
            # 'special_tokens_mask': special_tokens_mask,
            'labels': label['input_ids'],
                'decoder_attention_mask':label['attention_mask']
            }
    else:
        return {'graph': data,
                'input_ids': input_ids_out,
                'attention_mask': attention_mask_out,
                # 'special_tokens_mask': special_tokens_mask,
                'labels': label,
                }


def tokenize_function_gin_T5(examples,tokenizer,text_column_name,padding,max_seq_length,rich_features,transform_in_collator,**kwargs):
    # Remove empty lines
    # examples[text_column_name] = [line for line in examples[text_column_name] if len(line) > 0 and not line.isspace()]
    text = tokenizer(
        examples[text_column_name] if isinstance(examples[text_column_name],str) else examples[text_column_name][0],
        padding=padding,
        truncation=True,
        max_length=max_seq_length,
        # We use this option because DataCollatorForLanguageModeling (see below) is more efficient when it
        # receives the `special_tokens_mask`.
        return_special_tokens_mask=True,
    )
    labels = tokenizer(
        examples['label'],
        padding=padding,
        truncation=True,
        max_length=max_seq_length,
        # We use this option because DataCollatorForLanguageModeling (see below) is more efficient when it
        # receives the `special_tokens_mask`.
        return_special_tokens_mask=True,
    )


    # graph_data = smiles2graph(examples['graph'])
    if not transform_in_collator:
        graph_data = smiles2graph(examples['graph'])
    else:
        graph_data = examples['graph']

    return {'graph': graph_data,
            'input_ids': text.data['input_ids'],
            'attention_mask': text.data['attention_mask'],
            'special_tokens_mask': text.data['special_tokens_mask'],
            'labels': labels.data['input_ids']}


def tokenize_function_unico(examples, tokenizer, text_column_name, padding, max_seq_length, rich_features, transform_in_collator):
    # Remove empty lines
    # examples[text_column_name] = [line for line in examples[text_column_name] if len(line) > 0 and not line.isspace()]
    text = tokenizer(
        examples[text_column_name] if isinstance(examples[text_column_name],str) else examples[text_column_name][0], # if examples[text_column_name] is list
        padding=padding,
        truncation=True,
        max_length=max_seq_length,
        # We use this option because DataCollatorForLanguageModeling (see below) is more efficient when it
        # receives the `special_tokens_mask`.
        return_special_tokens_mask=True,
    )
    labels = tokenizer(
        str(examples['label']),
        padding=padding,
        truncation=True,
        max_length=max_seq_length,
        # We use this option because DataCollatorForLanguageModeling (see below) is more efficient when it
        # receives the `special_tokens_mask`.
        return_special_tokens_mask=True,
    )


    graph_data = examples['graph']


    if not transform_in_collator:
        if isinstance(graph_data, str):
            # 分子分支: SMILES → 图 → Graphormer 格式(原逻辑不变)
            graph_data = smiles2graph(examples['graph'])
            graph_data = graphormer_data_transform(graph_data,rich_features)
        # 【通用图分支】通用图样本的 graph 列是预处理好的图 dict
        # (pretrain_data_generation.py 输出), 无法 smiles2graph, 原样透传,
        # 图变换统一由 collator 的通用图分支完成(general_graph_transform_tensor)

    return {'graph': graph_data,
            'input_ids': text.data['input_ids'],
            'attention_mask': text.data['attention_mask'],
            'special_tokens_mask': text.data['special_tokens_mask'],
            'labels': labels.data['input_ids']}

# ---------------------------------------------------------------------------
# 兼容别名: 模型已更名 UniCO, 旧代码引用旧函数名时仍可用。
tokenize_function_gimlet = tokenize_function_unico
gimlet_add_prompt_conditional_generation_transform_single = \
    unico_add_prompt_conditional_generation_transform_single
