from ogb.utils import smiles2graph
import torch
import numpy as np
# from . import algos

import scipy
import setuptools
import pyximport

pyximport.install(setup_args={"include_dirs": np.get_include()})
from . import algos
import numbers
# @torch.jit.script
def convert_to_single_emb(x, offset: int = 512):
    feature_num = x.shape[1] if len(x.shape) > 1 else 1
    feature_offset = (1 + np.arange(0, feature_num * offset, offset)).astype("long")
    x = x + feature_offset
    return x

def build_in_edge_features(edge_index, edge_attr, num_nodes):
    if len(edge_attr.shape) == 1:
        edge_attr = edge_attr[:, None]
    edge_attr = convert_to_single_emb(edge_attr) + 1
    in_edges = [[] for _ in range(num_nodes)]
    for edge_id in range(edge_index.shape[1]):
        dst = int(edge_index[1, edge_id])
        in_edges[dst].append(edge_attr[edge_id])
    max_in_degree = max([len(edges) for edges in in_edges] + [1])
    in_edge_feats = np.zeros([num_nodes, max_in_degree, edge_attr.shape[-1]]).astype('long')
    for node_id, edges in enumerate(in_edges):
        if len(edges) > 0:
            in_edge_feats[node_id, :len(edges), :] = np.stack(edges, axis=0)
    return in_edge_feats


def build_in_edge_features_tensor(edge_index, edge_attr, num_nodes):
    if len(edge_attr.size()) == 1:
        edge_attr = edge_attr[:, None]
    edge_attr = convert_to_single_emb(edge_attr) + 1
    in_edges = [[] for _ in range(num_nodes)]
    for edge_id in range(edge_index.size(1)):
        dst = int(edge_index[1, edge_id])
        in_edges[dst].append(edge_attr[edge_id])
    max_in_degree = max([len(edges) for edges in in_edges] + [1])
    in_edge_feats = edge_attr.new_zeros([num_nodes, max_in_degree, edge_attr.size(-1)])
    for node_id, edges in enumerate(in_edges):
        if len(edges) > 0:
            in_edge_feats[node_id, :len(edges), :] = torch.stack(edges, dim=0)
    return in_edge_feats


#graphormer_data_transform is for numpy data, and graphormer_data_transform_tensor is for tensor data

def graphormer_data_transform(item,rich_features=False):
    #input item is standard graph data get by smiles2graph
    if 'node_feat' in item and 'edge_feat' in item:
        edge_attr, edge_index, x = item['edge_feat'], item['edge_index'], item['node_feat']
    elif hasattr(item, 'x') and hasattr(item, 'edge_attr'):
        edge_attr, edge_index, x = item.edge_attr, item.edge_index, item.x
    else:
        raise ValueError('item does not have expected keys or properties')

    if not rich_features:
        x = x[:,0:2]
        edge_attr = edge_attr[:,0:2]

    in_edge_feats = build_in_edge_features(edge_index, edge_attr, x.shape[0])

    N = x.shape[0]
    x = convert_to_single_emb(x)

    # node adj matrix [N, N] bool
    adj = np.zeros([N, N]).astype(bool)
    adj[edge_index[0, :], edge_index[1, :]] = True

    # edge feature here
    if len(edge_attr.shape) == 1:
        edge_attr = edge_attr[:, None]
    attn_edge_type = np.zeros([N, N, edge_attr.shape[-1]]).astype('long')
    attn_edge_type[edge_index[0, :], edge_index[1, :]] = (
        convert_to_single_emb(edge_attr) + 1
    )

    shortest_path_result, path = algos.floyd_warshall(adj)
    # shortest_path_result2, path2 = scipy.sparse.csgraph.floyd_warshall(adj,return_predecessors=True)
    # shortest_path_result3, path3 = algos2.floyd_warshall(adj)
    max_dist = np.amax(shortest_path_result)
    edge_input = algos.gen_edge_input(max_dist, path, attn_edge_type)
    # edge_input2 = algos2.gen_edge_input(max_dist, path, attn_edge_type)
    spatial_pos = shortest_path_result.astype('long')
    attn_bias = np.zeros([N + 1, N + 1]).astype('float')  # with graph token

    # combine

    #Data type will also be transformed into dict type in cache
    # item_new=Data()
    item_new = {}
    item_new['x'] = x
    item_new['attn_bias'] = attn_bias
    item_new['attn_edge_type'] = attn_edge_type
    item_new['spatial_pos'] = spatial_pos
    item_new['in_degree'] = adj.astype('long').sum(1)
    item_new['out_degree'] = item_new['in_degree']  # for undirected graph
    item_new['edge_input'] = edge_input.astype('long')
    item_new['in_edge_feats'] = in_edge_feats

    return item_new


def graphormer_data_transform_tensor(item,rich_features=False):
    if 'node_feat' in item and 'edge_feat' in item:
        edge_attr, edge_index, x = item['edge_feat'].long(), item['edge_index'].long(), item['node_feat'].long()
    elif hasattr(item, 'x') and hasattr(item, 'edge_attr'):
        edge_attr, edge_index, x = item.edge_attr.long(), item.edge_index.long(), item.x.long()
    else:
        raise ValueError('item does not have expected keys or properties')

    if not rich_features:
        x = x[:,0:2]
        edge_attr = edge_attr[:,0:2]

    in_edge_feats = build_in_edge_features_tensor(edge_index, edge_attr, x.size(0))


    N = x.size(0)
    x = convert_to_single_emb(x)

    # node adj matrix [N, N] bool
    adj = torch.zeros([N, N], dtype=torch.bool)
    adj[edge_index[0, :], edge_index[1, :]] = True

    # edge feature here
    if len(edge_attr.size()) == 1:
        edge_attr = edge_attr[:, None]
    attn_edge_type = torch.zeros([N, N, edge_attr.size(-1)], dtype=torch.long)
    attn_edge_type[edge_index[0, :], edge_index[1, :]] = (
        convert_to_single_emb(edge_attr) + 1
    )

    shortest_path_result, path = algos.floyd_warshall(adj.numpy())
    max_dist = np.amax(shortest_path_result)
    edge_input = algos.gen_edge_input(max_dist, path, attn_edge_type.numpy())
    spatial_pos = torch.from_numpy((shortest_path_result)).long()
    attn_bias = torch.zeros([N + 1, N + 1], dtype=torch.float)  # with graph token

    # combine
    item.x = x
    item.attn_bias = attn_bias
    item.attn_edge_type = attn_edge_type
    item.spatial_pos = spatial_pos
    item.in_degree = adj.long().sum(dim=1).view(-1)
    item.out_degree = item.in_degree  # for undirected graph
    item.edge_input = torch.from_numpy(edge_input).long()
    item.in_edge_feats = in_edge_feats

    return item


def graphormer_transform_for_dataset(examples,rich_features):
    graph_data = smiles2graph(examples['graph'])
    graph_data = graphormer_data_transform(graph_data, rich_features)
    examples['graph']=graph_data
    return examples


# ==========================================================================
# 【通用图分支】学术/社交图(arxiv_2023/pubmed/reddit) → Graphormer 格式
#
# 与分子图 graphormer_data_transform_tensor 的差异:
#   1. 节点特征为连续浮点(已由 pretrain_data_generation.py 零填充至 512 维),
#      直接保留 —— 不做前2维截取、不做 convert_to_single_emb 类别偏移映射;
#   2. 通用图无边特征: 构造全零 attn_edge_type / edge_input 占位, 不生成
#      in_edge_feats(模型端 UniCOEncoderStack 检测到无该字段时自动禁用
#      边协方差算子, 见 _has_graph_field / _aggregate_edge_features);
#   3. 邻接矩阵无向化(学术/社交图可能为有向), 入度=出度=无向度(与分子路径一致);
#   4. 全零特征行置 1e-6 微扰, 防止被模型 _valid_node_mask 误判为 padding 节点。
#
# 分子分支(原有逻辑)完全不受影响: 本函数仅由 collator 在检测到通用图时调用。
# ==========================================================================
def general_graph_transform_tensor(item):
    x = item.node_feat.to(torch.float32)
    edge_index = item.edge_index.long()
    n = x.size(0)

    # 异常防护: 全零特征行会被模型当作 padding 节点, 置微小值保留其有效位
    zero_rows = x.abs().sum(dim=-1) == 0
    if zero_rows.any():
        x = x.clone()
        x[zero_rows, 0] = 1e-6

    # 邻接矩阵(无向化)
    adj = torch.zeros([n, n], dtype=torch.bool)
    if edge_index.numel() > 0:
        valid = (edge_index[0] < n) & (edge_index[1] < n)
        edge_index = edge_index[:, valid]
        adj[edge_index[0], edge_index[1]] = True
    adj = adj | adj.t()

    # 最短路径距离(与分子路径共用 algos.floyd_warshall, 不可达节点约定为 510)
    shortest_path_result, _ = algos.floyd_warshall(adj.numpy())
    spatial_pos = torch.from_numpy(shortest_path_result).long()

    in_degree = adj.long().sum(dim=1)
    attn_bias = torch.zeros([n + 1, n + 1], dtype=torch.float)
    attn_edge_type = torch.zeros([n, n, 1], dtype=torch.long)      # 无边特征占位
    edge_input = torch.zeros([n, n, 1, 1], dtype=torch.long)       # 无边特征占位

    item.x = x
    item.attn_bias = attn_bias
    item.attn_edge_type = attn_edge_type
    item.spatial_pos = spatial_pos
    item.in_degree = in_degree
    item.out_degree = in_degree.clone()  # 按无向图处理, 与分子路径一致
    item.edge_input = edge_input
    # 注意: 不设置 in_edge_feats, 模型端据此自动关闭边协方差算子
    return item


def tokenize_function_graphormer_multitask(examples,rich_features,transform_in_collator):

    graph_data = smiles2graph(examples['graph'])

    # from pretrain_datasets.ChEMBL_STRING.mole_key import key_int, key_float

    label_cla=[]
    label_reg=[]
    for key in examples.keys():
        if len(key)>=4 and key[0:4]=='cla_':
            label_cla.append(examples[key])
        elif len(key)>=4 and key[0:4]=='reg_':
            label_reg.append(examples[key])

    if not transform_in_collator:
        graph_data = graphormer_data_transform(graph_data,rich_features)

    return {'graph': graph_data,
            'label_cla': label_cla,
            'label_reg': label_reg,}