import copy
from typing import Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.checkpoint import checkpoint
from transformers.models.t5.modeling_t5 import T5Stack
from transformers.modeling_outputs import BaseModelOutputWithPastAndCrossAttentions
from transformers.utils import logging

from model.graphormer.modules.graphormer_layers import GraphNodeFeature
from model.graphormer.modules.layer_norm import LayerNorm

logger = logging.get_logger(__name__)


class UniCOEncoderStack(T5Stack):
    def __init__(self, config, graph_args, embed_tokens=None):
        super().__init__(config, embed_tokens=embed_tokens)

        if graph_args.encoder_embed_dim > 0 and graph_args.encoder_embed_dim != self.config.d_model:
            raise ValueError("Warning! Inconsistent graph encoder_embed_dim and transformer d_model for Unimodel")
        graph_args.encoder_embed_dim = self.config.d_model
        if graph_args.encoder_attention_heads > 0 and graph_args.encoder_attention_heads != self.config.num_heads:
            raise ValueError("Warning! Inconsistent graph encoder_attention_heads and transformer num_heads for Unimodel")
        graph_args.encoder_attention_heads = self.config.num_heads
        if graph_args.encoder_layers > 0 and graph_args.encoder_layers != self.config.num_layers:
            raise ValueError("Warning! Inconsistent graph encoder_layers and transformer num_layers for Unimodel")
        graph_args.encoder_layers = self.config.num_layers

        self.graph_args = graph_args
        self.hidden_size = self.config.d_model
        self.num_heads = self.config.num_heads
        self.cov_max_order = int(getattr(graph_args, "cov_max_order", 2))
        self.text_window_size = int(getattr(graph_args, "text_window_size", 2))
        self.use_edge_covariance = bool(getattr(graph_args, "use_edge_covariance", True))
        self.alpha_init = float(getattr(graph_args, "alpha_init", 0.1))
        self.beta_init = float(getattr(graph_args, "beta_init", 0.1))
        self.operator_scale = float(getattr(graph_args, "operator_scale", 1.0))
        self.proj_scale = float(getattr(graph_args, "proj_scale", 1.0))
        self.proj_norm = bool(getattr(graph_args, "proj_norm", True))
        self.cov_eps = float(getattr(graph_args, "cov_eps", 1e-6))
        self.cov_clip_value = float(getattr(graph_args, "cov_clip_value", 20.0))
        self.operator_dropout = nn.Dropout(float(getattr(graph_args, "operator_dropout", 0.0)))
        self.mask_text_to_graph = bool(getattr(graph_args, "mask_text_to_graph", True))
        self.maskt2g = bool(getattr(graph_args, "maskt2g", True))
        self.edge_embed_dim = int(getattr(graph_args, "edge_embed_dim", 512))
        self.projection_resample_steps = max(int(getattr(graph_args, "projection_resample_steps", 50)), 1)
        self._projection_step = 0
        self._projection_cache = {}

        self.graph_node_feature = GraphNodeFeature(
            num_heads=self.num_heads,
            num_atoms=graph_args.num_atoms,
            num_in_degree=graph_args.num_in_degree,
            num_out_degree=graph_args.num_out_degree,
            hidden_dim=self.hidden_size,
            n_layers=graph_args.encoder_layers,
        )
        self.edge_feature_embedding = nn.Embedding(graph_args.num_edges + 1, self.edge_embed_dim, padding_idx=0)
        self.graph_input_norm = LayerNorm(self.hidden_size)
        self.text_input_norm = LayerNorm(self.hidden_size)
        self.edge_input_norm = LayerNorm(self.hidden_size)
        self.union_input_norm = LayerNorm(self.hidden_size)

        self.alpha_raw = nn.Parameter(torch.full((self.num_heads,), self.alpha_init))
        self.beta_raw = nn.Parameter(torch.full((self.num_heads,), self.beta_init))
        self.text_bias_raw = nn.Parameter(torch.ones(self.num_heads))
        self.register_buffer(
            "head_operator_index",
            torch.arange(self.num_heads, dtype=torch.long) % (self.cov_max_order + 3),
            persistent=False,
        )

        self.position_embedding_graph = nn.Embedding(1, self.block[0].layer[0].SelfAttention.n_heads)

    def _sample_random_projection(self, in_dim: int, out_dim: int, device, dtype):
        cache_key = (in_dim, out_dim, str(device), str(dtype))
        need_resample = (
            cache_key not in self._projection_cache
            or self._projection_step % self.projection_resample_steps == 0
        )
        if need_resample:
            proj = torch.randn(in_dim, out_dim, device=device, dtype=torch.float32)
            proj = proj / max(in_dim, 1) ** 0.5
            self._projection_cache[cache_key] = proj.to(dtype=dtype)
        return self._projection_cache[cache_key]

    def _valid_node_mask(self, graph):
        node_x = graph["x"]
        if node_x.dim() == 3:
            mask = node_x.abs().sum(dim=-1) > 0
        else:
            mask = node_x.ne(0)
        # 【通用图分支】批次含通用学术/社交图时(x_float 字段存在), 将其非零掩码并入。
        # 分子批次无该字段, 原逻辑不受影响。
        if self._has_graph_field(graph, "x_float"):
            mask = mask | (graph["x_float"].abs().sum(dim=-1) > 0)
        return mask

    def _center_features(self, feats, mask):
        mask = mask.to(dtype=feats.dtype).unsqueeze(-1)
        denom = mask.sum(dim=1, keepdim=True).clamp_min(1.0)
        mean = (feats * mask).sum(dim=1, keepdim=True) / denom
        return (feats - mean) * mask

    def _project_features(self, feats, mask, norm_layer):
        proj = self._sample_random_projection(feats.size(-1), self.hidden_size, feats.device, feats.dtype)
        feats = torch.matmul(feats, proj) * self.proj_scale
        if self.proj_norm:
            feats = norm_layer(feats)
        feats = self.operator_dropout(feats)
        return self._center_features(feats, mask)

    def _build_text_adjacency(self, attention_mask):
        if attention_mask is None:
            raise ValueError("attention_mask is required for text operator construction")
        valid = attention_mask.to(torch.bool)
        batch_size, seq_len = valid.shape
        if seq_len == 0:
            return valid.new_zeros((batch_size, 0, 0), dtype=torch.float32)
        positions = torch.arange(seq_len, device=attention_mask.device)
        dist = (positions[None, :] - positions[:, None]).abs()
        window = max(int(self.text_window_size), 0)
        adj = dist <= window
        adj = adj.unsqueeze(0).expand(batch_size, -1, -1)
        adj = adj & valid.unsqueeze(1) & valid.unsqueeze(2)
        eye = torch.eye(seq_len, device=attention_mask.device, dtype=torch.bool).unsqueeze(0)
        adj = adj | (eye & valid.unsqueeze(1) & valid.unsqueeze(2))
        return adj.to(dtype=torch.float32)

    def _build_graph_adjacency(self, graph):
        spatial_pos = graph["spatial_pos"]
        node_mask = self._valid_node_mask(graph)
        adj = spatial_pos.eq(2) & node_mask.unsqueeze(1) & node_mask.unsqueeze(2)
        eye = torch.eye(adj.size(-1), device=adj.device, dtype=torch.bool).unsqueeze(0)
        adj = adj | (eye & node_mask.unsqueeze(1) & node_mask.unsqueeze(2))
        return adj.to(dtype=torch.float32)

    def _build_information_flow_mask(self, text_mask):
        batch_size, seq_len = text_mask.shape
        if seq_len == 0:
            return text_mask.new_zeros((batch_size, 0, 0), dtype=torch.float32)
        flow = torch.tril(torch.ones(seq_len, seq_len, device=text_mask.device, dtype=torch.bool))
        flow = flow.unsqueeze(0).expand(batch_size, -1, -1)
        flow = flow & text_mask.unsqueeze(1) & text_mask.unsqueeze(2)
        return flow.to(dtype=torch.float32)

    def _normalize_adjacency(self, adj):
        deg = adj.sum(dim=-1).clamp_min(1.0)
        inv_sqrt = deg.pow(-0.5)
        return adj * inv_sqrt.unsqueeze(-1) * inv_sqrt.unsqueeze(-2)

    def _propagate(self, feats, adj_norm, max_order):
        propagated = [feats]
        cur = feats
        for _ in range(max_order):
            cur = torch.bmm(adj_norm, cur)
            cur = self.operator_dropout(cur)
            propagated.append(cur)
        return propagated

    def _covariance_from_centered(self, feats):
        cov = torch.bmm(feats, feats.transpose(1, 2)) / max(feats.size(-1), 1)
        cov = cov.clamp(min=-self.cov_clip_value, max=self.cov_clip_value)
        return cov

    def _covariance(self, feats, mask):
        centered = self._center_features(feats, mask)
        return self._covariance_from_centered(centered)

    def _aggregate_edge_features(self, graph, node_mask):
        if not self._has_graph_field(graph, "in_edge_feats"):
            return None
        in_edge_feats = graph["in_edge_feats"].long().clamp(min=0, max=self.edge_feature_embedding.num_embeddings - 1)
        edge_emb = self.edge_feature_embedding(in_edge_feats).mean(dim=-2)
        edge_mask = in_edge_feats.ne(0).any(dim=-1).to(edge_emb.dtype).unsqueeze(-1)
        edge = (edge_emb * edge_mask).sum(dim=2)
        edge = edge * node_mask.to(edge.dtype).unsqueeze(-1)
        return edge

    def _has_graph_field(self, graph, key):
        try:
            return key in graph
        except Exception:
            return hasattr(graph, key)

    def _build_union_bias_bank(self, graph, graph_feats, text_feats, graph_adj, text_adj, graph_mask, text_mask):
        batch_size, graph_len, _ = graph_feats.shape
        text_len = text_feats.size(1)
        union_len = graph_len + text_len

        union_feats = torch.cat([graph_feats, text_feats], dim=1)
        union_mask = torch.cat([graph_mask, text_mask], dim=1)
        union_adj = union_feats.new_zeros((batch_size, union_len, union_len))
        union_adj[:, :graph_len, :graph_len] = graph_adj
        union_adj[:, graph_len:, graph_len:] = text_adj
        union_adj = self._normalize_adjacency(union_adj)
        text_if_mask = self._build_information_flow_mask(text_mask)

        cov_ops = []
        cur_feats = union_feats
        for order in range(self.cov_max_order + 1):
            if order > 0:
                cur_feats = torch.bmm(union_adj, cur_feats)
                cur_graph = self._center_features(cur_feats[:, :graph_len, :], graph_mask)
                cur_text = self._center_features(cur_feats[:, graph_len:, :], text_mask)
                cur_feats = torch.cat([cur_graph, cur_text], dim=1)
                cur_feats = self.operator_dropout(cur_feats)

            cov_k = self._covariance_from_centered(cur_feats)
            cov_k = cov_k * union_mask.unsqueeze(1).to(cov_k.dtype) * union_mask.unsqueeze(2).to(cov_k.dtype)
            cov_k = cov_k.clamp(min=-self.cov_clip_value, max=self.cov_clip_value)

            # C_tt uses the autoregressive information-flow mask, not A_t.
            cov_k = cov_k.clone()
            cov_k[:, graph_len:, graph_len:] = cov_k[:, graph_len:, graph_len:] * text_if_mask
            cov_k[:, :graph_len, graph_len:] = 0.0
            cov_ops.append(cov_k)

        # The first two operators are the identity and the structural adjacency.
        eye = torch.eye(union_len, device=union_feats.device, dtype=union_feats.dtype).unsqueeze(0).expand(batch_size, -1, -1)
        op_bank = [eye, union_adj] + cov_ops

        zero = union_feats.new_zeros((batch_size, union_len, union_len))
        edge_ops = [zero.clone(), zero.clone()]
        if self.use_edge_covariance and self._has_graph_field(graph, "in_edge_feats"):
            graph_edge = self._aggregate_edge_features(graph, graph_mask)
            graph_edge = self._project_features(graph_edge, graph_mask, self.edge_input_norm)
            graph_adj_norm = self._normalize_adjacency(graph_adj)
            cur_edge = graph_edge
            graph_block_mask = graph_mask.unsqueeze(1) & graph_mask.unsqueeze(2)
            for order in range(self.cov_max_order + 1):
                if order > 0:
                    cur_edge = torch.bmm(graph_adj_norm, cur_edge)
                    cur_edge = self._center_features(cur_edge, graph_mask)
                    cur_edge = self.operator_dropout(cur_edge)
                cov_e = self._covariance_from_centered(cur_edge)
                cov_e = cov_e * graph_block_mask.to(cov_e.dtype)
                cov_full = cov_e.new_zeros((batch_size, union_len, union_len))
                cov_full[:, :graph_len, :graph_len] = cov_e
                edge_ops.append(cov_full)
        else:
            edge_ops.extend([zero.clone() for _ in cov_ops])

        return op_bank, edge_ops, union_mask, graph_len, text_len

    def _build_operator_bias(self, graph, input_ids, attention_mask, inputs_embeds=None):
        graph = graph.to(input_ids.device if input_ids is not None else inputs_embeds.device)
        graph_mask = self._valid_node_mask(graph)
        graph_feats = self.graph_node_feature(graph)[:, 1:, :]
        # 【通用图分支】连续节点特征(x_float, 学术/社交图)直接随机投影, 与分子分支输出相加。
        # - 分子样本: x_float 为全零行 → 投影输出 0, 分子路径完全不变;
        # - 通用样本: x 为全零行且度数被 collator 置 0 → GraphNodeFeature 输出 0,
        #   仅通用分支生效; 两条分支按样本互斥, 求和等价于各自独立前向。
        # 纯分子批次无 x_float 字段, 此分支零开销。
        if self._has_graph_field(graph, "x_float"):
            gen_feats = graph["x_float"].to(dtype=torch.float32)
            gen_feats = self._project_features(gen_feats, graph_mask, self.graph_input_norm)
            graph_feats = graph_feats + gen_feats
        graph_feats = self._project_features(graph_feats, graph_mask, self.graph_input_norm)
        graph_adj = self._build_graph_adjacency(graph)

        if inputs_embeds is not None:
            text_feats = inputs_embeds
        else:
            assert input_ids is not None, "either input_ids or inputs_embeds must be provided"
            text_feats = self.embed_tokens(input_ids)
        text_mask = attention_mask.to(torch.bool) if attention_mask is not None else torch.ones(
            text_feats.size()[:2], device=text_feats.device, dtype=torch.bool
        )
        text_feats = self._project_features(text_feats, text_mask, self.text_input_norm)
        text_adj = self._build_text_adjacency(text_mask)

        op_bank, edge_ops, union_mask, graph_len, text_len = self._build_union_bias_bank(
            graph, graph_feats, text_feats, graph_adj, text_adj, graph_mask, text_mask
        )

        op_bank = torch.stack(op_bank, dim=1)  # [B, O, L, L]
        edge_ops = torch.stack(edge_ops, dim=1)  # [B, O, L, L]
        head_map = self.head_operator_index.to(op_bank.device)
        op_bank = op_bank.index_select(1, head_map)
        edge_ops = edge_ops.index_select(1, head_map)

        alpha = torch.tanh(self.alpha_raw).to(op_bank.dtype) * self.operator_scale
        beta = torch.tanh(self.beta_raw).to(op_bank.dtype) * self.operator_scale
        bias = alpha.view(1, -1, 1, 1) * op_bank + beta.view(1, -1, 1, 1) * edge_ops

        # T5 relative position bias is expanded to the unified graph-text layout and
        # scaled per head, so its magnitude can be learned jointly with operator terms.
        text_bias = self.block[0].layer[0].SelfAttention.compute_bias(
            text_len, text_len, device=op_bank.device
        )
        text_bias_scale = torch.tanh(self.text_bias_raw).to(op_bank.dtype) * self.operator_scale
        text_bias_full = bias.new_zeros((bias.size(0), bias.size(1), graph_len + text_len, graph_len + text_len))
        text_bias_full[:, :, graph_len:, graph_len:] = text_bias.repeat(text_bias_full.size(0), 1, 1, 1)
        full_bias = bias + text_bias_scale.view(1, -1, 1, 1) * text_bias_full

        if self.mask_text_to_graph or self.maskt2g:
            full_bias[:, :, :graph_len, graph_len:] = float("-inf")

        # Guard against rare oversized values before softmax.
        finite_mask = torch.isfinite(full_bias)
        full_bias = torch.where(
            finite_mask,
            full_bias.clamp(min=-self.cov_clip_value, max=self.cov_clip_value),
            full_bias,
        )

        return full_bias, union_mask, graph_len, text_len, graph_feats, text_feats

    def forward(
        self,
        graph=None,
        input_ids=None,
        attention_mask=None,
        encoder_hidden_states=None,
        encoder_attention_mask=None,
        inputs_embeds=None,
        head_mask=None,
        cross_attn_head_mask=None,
        past_key_values=None,
        use_cache=None,
        output_attentions=None,
        output_hidden_states=None,
        return_dict=None,
    ):
        if graph is None:
            raise ValueError("graph input is required for UniCO encoder")
        self._projection_step += 1

        device = input_ids.device if input_ids is not None else inputs_embeds.device
        graph = graph.to(device)

        use_cache = use_cache if use_cache is not None else self.config.use_cache
        output_attentions = output_attentions if output_attentions is not None else self.config.output_attentions
        output_hidden_states = output_hidden_states if output_hidden_states is not None else self.config.output_hidden_states
        return_dict = return_dict if return_dict is not None else self.config.use_return_dict

        if input_ids is not None and inputs_embeds is not None:
            err_msg_prefix = "decoder_" if self.is_decoder else ""
            raise ValueError(
                f"You cannot specify both {err_msg_prefix}input_ids and {err_msg_prefix}inputs_embeds at the same time"
            )
        elif input_ids is not None:
            input_shape = input_ids.size()
            input_ids = input_ids.view(-1, input_shape[-1])
        elif inputs_embeds is not None:
            input_shape = inputs_embeds.size()[:-1]
        else:
            err_msg_prefix = "decoder_" if self.is_decoder else ""
            raise ValueError(f"You have to specify either {err_msg_prefix}input_ids or {err_msg_prefix}inputs_embeds")

        if attention_mask is None:
            attention_mask = torch.ones(input_shape, device=device, dtype=torch.long)

        if past_key_values is None:
            past_key_values = [None] * len(self.block)

        head_mask = self.get_head_mask(head_mask, self.config.num_layers)
        cross_attn_head_mask = self.get_head_mask(cross_attn_head_mask, self.config.num_layers)
        present_key_value_states = () if use_cache else None
        all_hidden_states = () if output_hidden_states else None
        all_attentions = () if output_attentions else None
        all_cross_attentions = () if (output_attentions and self.is_decoder) else None
        encoder_decoder_position_bias = None

        position_bias_merged, merged_mask, graph_len, text_len, graph_feats, text_feats = self._build_operator_bias(
            graph=graph,
            input_ids=input_ids,
            attention_mask=attention_mask,
            inputs_embeds=inputs_embeds,
        )

        if inputs_embeds is None:
            assert self.embed_tokens is not None, "You have to initialize the model with valid token embeddings"
            inputs_embeds = self.embed_tokens(input_ids)

        batch_size = text_feats.size(0)
        hidden_states = torch.cat([graph_feats, text_feats], dim=1)
        hidden_states = self.union_input_norm(hidden_states)
        hidden_states = self.dropout(hidden_states)

        merged_attention_mask = merged_mask.to(dtype=attention_mask.dtype if attention_mask is not None else torch.long)
        input_shape_merged = (batch_size, graph_len + text_len)
        extended_attention_mask = self.get_extended_attention_mask(merged_attention_mask, input_shape_merged)

        if self.is_decoder and encoder_hidden_states is not None:
            encoder_batch_size, encoder_sequence_length, _ = encoder_hidden_states.size()
            encoder_hidden_shape = (encoder_batch_size, encoder_sequence_length)
            if encoder_attention_mask is None:
                encoder_attention_mask = torch.ones(encoder_hidden_shape, device=hidden_states.device)
            encoder_extended_attention_mask = self.invert_attention_mask(encoder_attention_mask)
        else:
            encoder_extended_attention_mask = None

        position_bias = None
        for i, (layer_module, past_key_value) in enumerate(zip(self.block, past_key_values)):
            layer_head_mask = head_mask[i]
            cross_attn_layer_head_mask = cross_attn_head_mask[i]

            if self.model_parallel:
                torch.cuda.set_device(hidden_states.device)
                if extended_attention_mask is not None:
                    extended_attention_mask = extended_attention_mask.to(hidden_states.device)
                if position_bias is not None:
                    position_bias = position_bias.to(hidden_states.device)
                if encoder_hidden_states is not None:
                    encoder_hidden_states = encoder_hidden_states.to(hidden_states.device)
                if encoder_extended_attention_mask is not None:
                    encoder_extended_attention_mask = encoder_extended_attention_mask.to(hidden_states.device)
                if encoder_decoder_position_bias is not None:
                    encoder_decoder_position_bias = encoder_decoder_position_bias.to(hidden_states.device)
                if layer_head_mask is not None:
                    layer_head_mask = layer_head_mask.to(hidden_states.device)
                if cross_attn_layer_head_mask is not None:
                    cross_attn_layer_head_mask = cross_attn_layer_head_mask.to(hidden_states.device)

            if output_hidden_states:
                all_hidden_states = all_hidden_states + (hidden_states,)

            if self.gradient_checkpointing and self.training:
                if use_cache:
                    logger.warning("`use_cache=True` is incompatible with gradient checkpointing. Setting `use_cache=False`...")
                    use_cache = False

                def create_custom_forward(module):
                    def custom_forward(*inputs):
                        return tuple(module(*inputs, use_cache, output_attentions))

                    return custom_forward

                layer_outputs = checkpoint(
                    create_custom_forward(layer_module),
                    hidden_states,
                    extended_attention_mask,
                    position_bias_merged,
                    encoder_hidden_states,
                    encoder_extended_attention_mask,
                    encoder_decoder_position_bias,
                    layer_head_mask,
                    cross_attn_layer_head_mask,
                    None,
                )
            else:
                layer_outputs = layer_module(
                    hidden_states,
                    attention_mask=extended_attention_mask,
                    position_bias=position_bias_merged,
                    encoder_hidden_states=encoder_hidden_states,
                    encoder_attention_mask=encoder_extended_attention_mask,
                    encoder_decoder_position_bias=encoder_decoder_position_bias,
                    layer_head_mask=layer_head_mask,
                    cross_attn_layer_head_mask=cross_attn_layer_head_mask,
                    past_key_value=past_key_value,
                    use_cache=use_cache,
                    output_attentions=output_attentions,
                )

            if use_cache is False:
                layer_outputs = layer_outputs[:1] + (None,) + layer_outputs[1:]

            hidden_states, present_key_value_state = layer_outputs[:2]
            position_bias = layer_outputs[2]
            if self.is_decoder and encoder_hidden_states is not None:
                encoder_decoder_position_bias = layer_outputs[4 if output_attentions else 3]

            if use_cache:
                present_key_value_states = present_key_value_states + (present_key_value_state,)

            if output_attentions:
                all_attentions = all_attentions + (layer_outputs[3],)
                if self.is_decoder:
                    all_cross_attentions = all_cross_attentions + (layer_outputs[5],)

            if self.model_parallel:
                for k, v in self.device_map.items():
                    if i == v[-1] and "cuda:" + str(k) != self.last_device:
                        hidden_states = hidden_states.to("cuda:" + str(k + 1))

        hidden_states = self.final_layer_norm(hidden_states)
        hidden_states = self.dropout(hidden_states)

        # Keep decoder-visible states text-only.
        hidden_states_text = hidden_states[:, graph_len:, :]

        if output_hidden_states:
            all_hidden_states = all_hidden_states + (hidden_states_text,)

        if not return_dict:
            return tuple(
                v
                for v in [
                    hidden_states_text,
                    present_key_value_states,
                    all_hidden_states,
                    all_attentions,
                    all_cross_attentions,
                ]
                if v is not None
            )

        return BaseModelOutputWithPastAndCrossAttentions(
            last_hidden_state=hidden_states_text,
            past_key_values=present_key_value_states,
            hidden_states=all_hidden_states,
            attentions=all_attentions,
            cross_attentions=all_cross_attentions,
        )

    def forward_graph_only(
        self,
        graph=None,
        head_mask=None,
        cross_attn_head_mask=None,
        past_key_values=None,
        use_cache=None,
        output_attentions=None,
        output_hidden_states=None,
        return_dict=None,
    ):
        if graph is None:
            raise ValueError("graph input is required for graph-only forward")
        graph = graph.to(self.position_embedding_graph.weight.device)
        graph_mask = self._valid_node_mask(graph)
        graph_feats = self.graph_node_feature(graph)[:, 1:, :]
        # 【通用图分支】同 _build_operator_bias: 连续节点特征随机投影后与分子分支相加,
        # 分子批次无 x_float 字段, 原逻辑不受影响。
        if self._has_graph_field(graph, "x_float"):
            gen_feats = graph["x_float"].to(dtype=torch.float32)
            gen_feats = self._project_features(gen_feats, graph_mask, self.graph_input_norm)
            graph_feats = graph_feats + gen_feats
        graph_feats = self._project_features(graph_feats, graph_mask, self.graph_input_norm)
        graph_adj = self._normalize_adjacency(self._build_graph_adjacency(graph))

        use_cache = use_cache if use_cache is not None else self.config.use_cache
        output_attentions = output_attentions if output_attentions is not None else self.config.output_attentions
        output_hidden_states = output_hidden_states if output_hidden_states is not None else self.config.output_hidden_states
        return_dict = return_dict if return_dict is not None else self.config.use_return_dict

        if past_key_values is None:
            past_key_values = [None] * len(self.block)

        head_mask = self.get_head_mask(head_mask, self.config.num_layers)
        cross_attn_head_mask = self.get_head_mask(cross_attn_head_mask, self.config.num_layers)
        present_key_value_states = () if use_cache else None
        all_hidden_states = () if output_hidden_states else None
        all_attentions = () if output_attentions else None
        all_cross_attentions = () if (output_attentions and self.is_decoder) else None
        encoder_decoder_position_bias = None

        hidden_states = self.dropout(self.union_input_norm(graph_feats))
        position_bias_merged = self._covariance(hidden_states, graph_mask).unsqueeze(1).repeat(1, self.num_heads, 1, 1)
        position_bias_merged = position_bias_merged.clamp(min=-self.cov_clip_value, max=self.cov_clip_value)
        extended_attention_mask = self.get_extended_attention_mask(
            graph_mask.to(dtype=torch.long), (graph_feats.size(0), graph_feats.size(1))
        )

        position_bias = None
        for i, (layer_module, past_key_value) in enumerate(zip(self.block, past_key_values)):
            layer_head_mask = head_mask[i]
            cross_attn_layer_head_mask = cross_attn_head_mask[i]
            if output_hidden_states:
                all_hidden_states = all_hidden_states + (hidden_states,)
            layer_outputs = layer_module(
                hidden_states,
                attention_mask=extended_attention_mask,
                position_bias=position_bias_merged,
                encoder_hidden_states=None,
                encoder_attention_mask=None,
                encoder_decoder_position_bias=encoder_decoder_position_bias,
                layer_head_mask=layer_head_mask,
                # [修复] T5Block.forward 的参数名为 cross_attn_layer_head_mask
                # (原写法 cross_attn_head_mask 在 transformers>=4.26 会报 TypeError)
                cross_attn_layer_head_mask=cross_attn_layer_head_mask,
                past_key_value=past_key_value,
                use_cache=use_cache,
                output_attentions=output_attentions,
            )
            if use_cache is False:
                layer_outputs = layer_outputs[:1] + (None,) + layer_outputs[1:]
            hidden_states, present_key_value_state = layer_outputs[:2]
            position_bias = layer_outputs[2]
            if use_cache:
                present_key_value_states = present_key_value_states + (present_key_value_state,)
            if output_attentions:
                all_attentions = all_attentions + (layer_outputs[3],)
            if self.model_parallel:
                for k, v in self.device_map.items():
                    if i == v[-1] and "cuda:" + str(k) != self.last_device:
                        hidden_states = hidden_states.to("cuda:" + str(k + 1))

        hidden_states = self.final_layer_norm(hidden_states)
        hidden_states = self.dropout(hidden_states)

        if output_hidden_states:
            all_hidden_states = all_hidden_states + (hidden_states,)

        if not return_dict:
            return tuple(v for v in [hidden_states, present_key_value_states, all_hidden_states, all_attentions, all_cross_attentions] if v is not None)

        return BaseModelOutputWithPastAndCrossAttentions(
            last_hidden_state=hidden_states,
            past_key_values=present_key_value_states,
            hidden_states=all_hidden_states,
            attentions=all_attentions,
            cross_attentions=all_cross_attentions,
        )


UniCOEncoderStackDict = {
    "unico": UniCOEncoderStack,   # 新规范名
    "gint5": UniCOEncoderStack,
    "gimlet": UniCOEncoderStack,  # 兼容旧命令/旧 checkpoint
}


# ---------------------------------------------------------------------------
# 兼容别名: 模型已更名 UniCO, 以下别名保证旧代码与旧 checkpoint(architecture/
# 代码中引用旧类名) 仍可加载, 新代码请使用 UniCO* 名称。
GIMLETEncoderStack = UniCOEncoderStack
GraphT5EncoderStack_dict = UniCOEncoderStackDict
